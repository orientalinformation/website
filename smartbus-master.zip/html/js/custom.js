$("#addInputDepartmentsInAdd").click(function() {
	var countTr = $("#inputDepartments tr").length + 1;
	var td = '<tr><td>'+countTr+'</td><td><input class="form-control" type="text" name="departments[]"></td></tr>';
	$("#inputDepartments tr:last").after(td);
});
$("#addInputDepartmentsInEdit").click(function() {
	var countTr = $("#inputDepartments tr").length + 1;
	var td = '<tr><td>'+countTr+'</td><td colspan="2"><input class="form-control" type="text" name="departments[]" placeholder="Department name"></td></tr>';
	$("#inputDepartments tr:last").after(td);
});

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});

var demo1 = $('select[name="duallistbox_demo1[]"]').bootstrapDualListbox({
	nonSelectedListLabel: 'Staffs',
	selectedListLabel: 'Staffs in the department',
});
$("#demoform").submit(function() {
	
  	alert($('[name="duallistbox_demo1[]"]').val());
  return false;
});

var role = localStorage.getItem("role");

if (role == 1) {
	$('#username').html("Xin chào Administrator!");
} else if (role == 2) {
	$('#username').html("Xin chào Manager!");
	$('.manager').css('display','none');
} else if (role == 3) {
	$('#username').html("Xin chào User!");
	$('.user').css('display','none');
	$('.user').css('display','none');
} else {
	window.location.href = "login.html";
}

$('#btnLogout').click(function(){
	localStorage.setItem("role", 0);
	window.location.href = "login.html";
});