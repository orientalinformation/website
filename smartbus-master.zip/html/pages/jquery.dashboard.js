
/**
* Theme: Uplon Admin Template
* Author: Coderthemes
* Dashboard
*/

!function($) {
    "use strict";

    var Dashboard = function() {};

    //creates Stacked chart
    Dashboard.prototype.createStackedChart  = function(element, data, xkey, ykeys, labels, lineColors) {
        Morris.Bar({
            element: element,
            data: data,
            xkey: xkey,
            ykeys: ykeys,
            stacked: true,
            labels: labels,
            hideHover: 'auto',
            barSizeRatio: 0.4,
            resize: true, //defaulted to true
            gridLineColor: '#eeeeee',
            barColors: lineColors
        });
    },


    //creates Donut chart
    Dashboard.prototype.createDonutChart = function(element, data, colors) {
        Morris.Donut({
            element: element,
            data: data,
            resize: true, //defaulted to true
            colors: colors
        });
    },

    Dashboard.prototype.init = function() {

        //creating Stacked chart
        var $stckedData  = [
            { y: 'Tháng 1', a: 3485, b: 5748 },
            { y: 'Tháng 2', a: 3986,  b: 4574 },
            { y: 'Tháng 3', a: 2653, b: 5478 },
            { y: 'Tháng 4', a: 3467,  b: 4689 },
            { y: 'Tháng 5', a: 2546, b: 4813 },
            { y: 'Tháng 6', a: 2748,  b: 5371 },
            { y: 'Tháng 7', a: 2894,  b: 5147 },
            { y: 'Tháng 8', a: 3271,  b: 4986 },
            { y: 'Tháng 9', a: 3140,  b: 5693 },
            { y: 'Tháng 10', a: 3612,  b: 5482 },
            { y: 'Tháng 11', a: 2349, b: 4714 },
            { y: 'Tháng 12', a: 2989, b: 5354 }
        ];
        this.createStackedChart('morris-bar-stacked', $stckedData, 'y', ['a' ,'b'], ['Máy cầm tay', 'Xe bus'], ['#666', '#009900']);

        //creating donut chart
        var $donutData = [
                {label: "English Language 01", value: 12},
                {label: "Italian Language 02", value: 30},
                {label: "French Language 03", value: 20}
            ];
        this.createDonutChart('morris-donut-example', $donutData, ['#3db9dc','#1bb99a', '#ebeff2']);
    },
    //init
    $.Dashboard = new Dashboard, $.Dashboard.Constructor = Dashboard
}(window.jQuery),

//initializing
function($) {
    "use strict";
    $.Dashboard.init();
}(window.jQuery);
