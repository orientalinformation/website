<?php
/**
 * Routes configuration
 *
 * In this file, you set up routes to your controllers and their actions.
 * Routes are very important mechanism that allows you to freely connect
 * different URLs to chosen controllers and their actions (functions).
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

use Cake\Core\Plugin;
use Cake\Routing\RouteBuilder;
use Cake\Routing\Router;
use Cake\Routing\Route\DashedRoute;

/**
 * The default class to use for all routes
 *
 * The following route classes are supplied with CakePHP and are appropriate
 * to set as the default:
 *
 * - Route
 * - InflectedRoute
 * - DashedRoute
 *
 * If no call is made to `Router::defaultRouteClass()`, the class used is
 * `Route` (`Cake\Routing\Route\Route`)
 *
 * Note that `Route` does not do any inflections on URLs which will result in
 * inconsistently cased URLs when used with `:plugin`, `:controller` and
 * `:action` markers.
 *
 */
Router::defaultRouteClass(DashedRoute::class);

Router::scope('/', function (RouteBuilder $routes) {
    /**
     * Here, we are connecting '/' (base path) to a controller called 'Pages',
     * its action called 'display', and we pass a param to select the view file
     * to use (in this case, src/Template/Pages/home.ctp)...
     */
    // $routes->connect('/', ['controller' => 'Pages', 'action' => 'display', 'home']);
    // $routes->connect('/', ['controller' => 'ServerApi', 'action' => 'index']);
    // $routes->connect('/logviewer.php', ['controller' => 'ServerApi', 'action' => 'logviewer']);


/* Begin API Server */
    $routes->connect('/api/v1/insertTicketByMachine', ['controller' => 'ServerApi', 'action' => 'insertTicketByMachine']);
    $routes->connect('/api/v1/checkTicket', ['controller' => 'ServerApi', 'action' => 'checkQrcode']);
    $routes->connect('/api/v1/checkInOutStaff', ['controller' => 'ServerApi', 'action' => 'checkInOutStaff']);
    $routes->connect('/api/v1/updateBusPosition', ['controller' => 'ServerApi', 'action' => 'updateBusPosition']);
    $routes->connect('/api/v1/updateDevicePosition', ['controller' => 'ServerApi', 'action' => 'updateDevicePosition']);
    $routes->connect('/api/v1/getTemplateTicket', ['controller' => 'ServerApi', 'action' => 'getTemplateTicket']);
    $routes->connect('/api/v1/insertReport', ['controller' => 'ServerApi', 'action' => 'insertRevenuesBus']);
    $routes->connect('/api/v1/backupData', ['controller' => 'ServerApi', 'action' => 'backupData']);
/* End API Server */    

/* Begin Manager */
    $routes->connect('/administrator/:id', ['controller' => 'Administrator', 'action' => 'index', 'id' => '[0-9]+']);
    $routes->connect('/administrator/follow-bus', ['controller' => 'Administrator', 'action' => 'followBus']);
    $routes->connect('/administrator/login', ['controller' => 'Administrator', 'action' => 'login']);
    $routes->connect('/administrator/logout', ['controller' => 'Administrator', 'action' => 'logout']);
    $routes->connect('/administrator/forgot-password', ['controller' => 'Administrator', 'action' => 'forgot']);
    
    $routes->connect('/administrator/roles', ['controller' => 'Administrator', 'action' => 'roles']);
    $routes->connect('/administrator/roles/add', ['controller' => 'Administrator', 'action' => 'addRole']);
    $routes->connect('/administrator/roles/edit/:id', ['controller' => 'Administrator', 'action' => 'editRole', 'id' => '[0-9]+']);
    $routes->connect('/administrator/roles/delete/:id', ['controller' => 'Administrator', 'action' => 'deleteRole', 'id' => '[0-9]+']);
/* End Manager */

/* Begin Company */
    $routes->connect('/administrator/companies', ['controller' => 'Companies', 'action' => 'index']);
    $routes->connect('/administrator/companies/getValueAjax', ['controller' => 'Companies', 'action' => 'getValueAjax']);
    $routes->connect('/administrator/companies/add', ['controller' => 'Companies', 'action' => 'add']);
    $routes->connect('/administrator/companies/edit', ['controller' => 'Companies', 'action' => 'edit']);
/* End Company */

/* Begin BusRoute */
    $routes->connect('/administrator/routes', ['controller' => 'BusRoutes', 'action' => 'index']);
    $routes->connect('/administrator/routes/add', ['controller' => 'BusRoutes', 'action' => 'add']);
    $routes->connect('/administrator/routes/edit/', ['controller' => 'BusRoutes', 'action' => 'edit', 'id' => '[0-9]+']);
    $routes->connect('/administrator/routes/delete/:id', ['controller' => 'BusRoutes', 'action' => 'delete', 'id' => '[0-9]+']);
    $routes->connect('/administrator/routes/stop_station/add', ['controller' => 'BusRoutes', 'action' => 'addStopStation']);
    $routes->connect('/administrator/routes/stop_station/delete', ['controller' => 'BusRoutes', 'action' => 'deleteStopStation']);
    $routes->connect('/administrator/routes/createFileBusStopJs', ['controller' => 'BusRoutes', 'action' => 'createFileBusStopJs']);
/* End BusRoute */

/* Begin Department */
    $routes->connect('/administrator/departments', ['controller' => 'Departments', 'action' => 'index']);
    $routes->connect('/administrator/departments/add', ['controller' => 'Departments', 'action' => 'add']);
    $routes->connect('/administrator/departments/edit', ['controller' => 'Departments', 'action' => 'edit']);
/* End Department */

/* Begin Staffs */
    $routes->connect('/administrator/staffs', ['controller' => 'Staffs', 'action' => 'index']);
    $routes->connect('/administrator/staffs/add', ['controller' => 'Staffs', 'action' => 'add']);
    $routes->connect('/administrator/staff/:id', ['controller' => 'Staffs', 'action' => 'user', 'id' => '[0-9]+']);
/* End Staffs */

/* Begin Buses */
    $routes->connect('/administrator/buses', ['controller' => 'Buses', 'action' => 'index']);
    $routes->connect('/administrator/buses/add', ['controller' => 'Buses', 'action' => 'add']);
    $routes->connect('/administrator/buses/edit', ['controller' => 'Buses', 'action' => 'edit']);
    $routes->connect('/administrator/buses/delete/:id', ['controller' => 'Buses', 'action' => 'delete', 'id' => '[0-9]+']);
/* End Buses */

/* Begin Devices */
    $routes->connect('/administrator/devices', ['controller' => 'Devices', 'action' => 'index']);
    $routes->connect('/administrator/devices/add', ['controller' => 'Devices', 'action' => 'add']);
    $routes->connect('/administrator/devices/edit', ['controller' => 'Devices', 'action' => 'edit']);
    $routes->connect('/administrator/devices/delete/:id/:type', ['controller' => 'Devices', 'action' => 'delete', 'id' => '[0-9]+', 'type' => '[0-9]+']);
/* End Devices */

/* Begin Tickets */
    $routes->connect('/administrator/tickets', ['controller' => 'Tickets', 'action' => 'index']);
    $routes->connect('/administrator/tickets/add', ['controller' => 'Tickets', 'action' => 'add']);
/* End Tickets */

/* Begin Reports */
    $routes->connect('/administrator/reports/tickets', ['controller' => 'Reports', 'action' => 'tickets']);
    $routes->connect('/administrator/reports/realtime', ['controller' => 'Reports', 'action' => 'realTime']);
    $routes->connect('/administrator/reports/calculate', ['controller' => 'Reports', 'action' => 'calculate']);
    $routes->connect('/administrator/reports/compare', ['controller' => 'Reports', 'action' => 'comparePeopleTicket']);
    $routes->connect('/administrator/reports/route', ['controller' => 'Reports', 'action' => 'ticketRoute']);
    $routes->connect('/administrator/reports/bus', ['controller' => 'Reports', 'action' => 'ticketBus']);
/* End Reports */

/* Begin Reports */
    $routes->connect('/administrator/users', ['controller' => 'Users', 'action' => 'index']);
    $routes->connect('/administrator/users/add', ['controller' => 'Users', 'action' => 'add']);
    $routes->connect('/administrator/users/edit', ['controller' => 'Users', 'action' => 'edit']);
    $routes->connect('/administrator/users/change-password/:id', ['controller' => 'Users', 'action' => 'changePassword', 'id' => '[0-9]+']);
/* End Reports */




    /**
     * ...and connect the rest of 'Pages' controller's URLs.
     */
    // $routes->connect('/pages/*', ['controller' => 'Pages', 'action' => 'display']);

    /**
     * Connect catchall routes for all controllers.
     *
     * Using the argument `DashedRoute`, the `fallbacks` method is a shortcut for
     *    `$routes->connect('/:controller', ['action' => 'index'], ['routeClass' => 'DashedRoute']);`
     *    `$routes->connect('/:controller/:action/*', [], ['routeClass' => 'DashedRoute']);`
     *
     * Any route class can be used with this method, such as:
     * - DashedRoute
     * - InflectedRoute
     * - Route
     * - Or your own route class
     *
     * You can remove these routes once you've connected the
     * routes you want in your application.
     */
    $routes->fallbacks(DashedRoute::class);
});

/**
 * Load all plugin routes.  See the Plugin documentation on
 * how to customize the loading of plugin routes.
 */
Plugin::routes();
