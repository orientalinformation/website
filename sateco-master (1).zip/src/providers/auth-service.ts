import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import { Headers, Http, Request, RequestOptions, RequestMethod } from '@angular/http';
import 'rxjs/add/operator/map';
import { Storage } from '@ionic/storage';

/*
  Generated class for the AuthService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/


@Injectable()
export class AuthService {

  constructor(public http: Http, public storage: Storage) {

    console.log('Hello AuthService Provider');
   
  }

  public host = "http://public.dfmvn.net/sateco";
  public token;

  public login(credentials) {
    var link = this.host + '/api/v1/user/login';
    var username = credentials.username;
    var password = credentials.password;
    let body = new FormData();
    body.append('username', username);
    body.append('password', password);
    // var data = JSON.stringify({username: "thaolt", password: "123456"});

    if (credentials.username === null || credentials.password === null) {
      return Observable.throw("Please insert credentials");
    } else {
      return Observable.create(observer => {
        this.http.post(link, body).map(res => res.json())
        .subscribe(data => {
          let access = data.status;
          this.storage.set('id_token', data.token);
          this.token = data.token;

          observer.next(access);
          observer.complete();
        }, error => {
            console.log("Oooops!");
        });
      });
    }
  }

  public register(credentials) {
    if (credentials.username === null || credentials.password === null) {
      return Observable.throw("Please insert credentials");
    } else if (credentials.password == credentials.password_confirm) {
      return Observable.create(observer => {
        var link = this.host + '/api/v1/register';
        var username = credentials.username;
        var password = credentials.password;
        var email = credentials.email;
        var company = "1";
        let body = new FormData();
        body.append('username', username);
        body.append('password', password);
        body.append('email', email);
        body.append('company_id', company);
        this.http.post(link, body).map(res => res.json())
        .subscribe(data => {
          observer.next(true);
          observer.complete();
        }, error => {
            console.log("Oooops!");
        });
      });
    } else {
      return Observable.throw("Please password confirm wrong!");
    }
  }

  public logout(token) {
    return Observable.create(observer => {
      var headers = new Headers();
      
      headers.append('Authorization', token);

      var link = this.host + '/api/v1/user/logout';

      let options = new RequestOptions({
          method: RequestMethod.Get,
          url: link,
          headers: headers
      });
      this.http.request(new Request(options))
      .map(res => res.json())
          .subscribe(data => {
            let access = data.status;
            observer.next(access);
            observer.complete();
          }, error => {
              console.log("Oooops!");
          });
      });
  }

}
