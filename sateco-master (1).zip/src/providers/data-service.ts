import { Injectable } from '@angular/core';
import { Headers, Http, Request, RequestOptions, RequestMethod } from '@angular/http';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map';

/*
  Generated class for the GetData provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/

export class Site {
  site: any;
 
  constructor(site) {
    this.site = site;
  }
}

export class Sites {
  sites: any;
  constructor(sites) {
    this.sites = sites;
  }
}

export class Banches {
  banches: any;
  constructor(banches) {
    this.banches = banches;
  }
}

export class Reading {
  reading: any;
  constructor(reading) {
    this.reading = reading;
  }
}

@Injectable()
export class DataService {


  constructor(public http: Http, public storage: Storage) {
    console.log('Hello GetData Provider');
  }

  public host = "http://public.dfmvn.net/sateco";
  currentSite: Site;
  currentSites: Sites;
  currentBanches: Banches;
  currentReading: Reading;

  public getSiteInfo() : Site {
    return this.currentSite;
  }

  public getSitesInfo() : Sites {
    return this.currentSites;
  }

  public getBanchesInfo() : Banches {
    return this.currentBanches;
  }

  public getReadingInfo() : Reading {
    return this.currentReading;
  }

  public getSite(token, site_id) {
    var headers = new Headers();
    headers.append('Authorization', token);

    var link = this.host + '/api/v1/site/' + site_id;
    let options = new RequestOptions({
        method: RequestMethod.Get,
        url: link,
        headers: headers
    });

    this.currentSite = new Site(this.http.request(new Request(options)).map(res => res.json()));
  }


  public getSites(token) {
    var headers = new Headers();
    headers.append('Authorization', token);

    var link = this.host + '/api/v1/sites';
    let options = new RequestOptions({
        method: RequestMethod.Get,
        url: link,
        headers: headers
    });
    this.currentSites = new Sites(this.http.get(link, options).map(res => res.json()));
  }

  public getBanches(token, site_id) {
    var headers = new Headers();
    headers.append('Authorization', token);

    var link = this.host + '/api/v1/banches/' + site_id;
    let options = new RequestOptions({
        method: RequestMethod.Get,
        url: link,
        headers: headers
    });
    this.currentBanches = new Banches(this.http.get(link, options).map(res => res.json()));
  }

  public getReading(token, banche_id) {
    var headers = new Headers();
    headers.append('Authorization', token);

    var link = this.host + '/api/v1/reading/' + banche_id;
    let options = new RequestOptions({
        method: RequestMethod.Get,
        url: link,
        headers: headers
    });
    this.currentReading = new Reading(this.http.get(link, options).map(res => res.json())); 
  }
}

