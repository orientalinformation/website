import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { DataService } from '../providers/data-service';
import { Chart } from 'chart.js';
/*
  Generated class for the GetData provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/

@Injectable()
export class ChartService {

    public currentReading;

    constructor(public dataservice: DataService) {
        console.log('Hello Chart Provider');
    }

    getThicknessRollPitch(token, banche_id, dataservice) {
        dataservice.getReading(token, banche_id);
        let currentReading = dataservice.getReadingInfo();
        currentReading = dataservice.getReadingInfo();
        return currentReading;
    }

    getDataTimeNow(token, banche_id, chart, dataDraw) {

        var arrDatas = [];
        var arrLabels = [];
        var last_id;
        this.dataservice.getDataTimeNow(token, banche_id);
        let currentReadings = this.dataservice.getReadingsInfo();
        currentReadings.readings.subscribe(data => {
            if (data.readings.length != 0) {
                for (let reading of data.readings) {
                    if (dataDraw == "pressure") {
                        if (reading.pressure != null) {
                            let arrDatetime = reading.created.split(" ");
                            arrLabels.push(arrDatetime[1]);
                            arrDatas.push(reading.pressure);
                            last_id = reading.id;
                        }
                    }

                    if (dataDraw == "height") {
                        if (reading.height != null) {
                            let arrDatetime = reading.created.split(" ");
                            arrLabels.push(arrDatetime[1]);
                            arrDatas.push(reading.height);
                            last_id = reading.id;
                        }
                    }

                }
                chart.data.datasets[0].data = arrDatas;
                chart.data.labels = arrLabels;
                chart.update();

                this.getDataRealTime(token, banche_id, last_id, chart, dataDraw);
            } else {
                this.dataservice.getReading(token, banche_id);
                let currentReading = this.dataservice.getReadingInfo();
                currentReading.reading.subscribe(data => {
                    last_id = data.reading.id;
                    this.getDataRealTime(token, banche_id, last_id, chart, dataDraw);
                });
            }
        });
    }

    getDataRealTime(token, banche_id, last_id, chart, dataDraw) {
        var that = this;

        setInterval(function() {
            that.dataservice.getDataRealTimeReading(token, banche_id, last_id);
            let currentReadings = that.dataservice.getReadingsInfo();
            currentReadings.readings.subscribe(data => {
                if (data.reading.length != 0) {
                    for (let reading of data.reading) {
                        if (dataDraw == "pressure") {
                            if (reading.pressure != null) {
                                let arrDatetime = reading.created.split(" ");
                                chart.data.labels.push(arrDatetime[1]);
                                chart.data.datasets[0].data.push(reading.pressure);
                                last_id = reading.id;
                            }
                        }
                        if (dataDraw == "height") {
                            if (reading.height != null) {
                                let arrDatetime = reading.created.split(" ");
                                chart.data.labels.push(arrDatetime[1]);
                                chart.data.datasets[0].data.push(reading.height);
                                last_id = reading.id;
                            }
                        }
                    }
                    chart.update();
                }
            });
        }, 5000);
    }

 

    // initHeightChart() {
    //   // Chart declaration:
    //     let chartType = 'line';

    //     let data = {
    //       datasets: [
    //             {
    //                 label: "Height",
    //                 fill: false,
    //                 lineTension: 0.1,
    //                 backgroundColor: "rgba(75,192,192,0.4)",
    //                 borderColor: "rgba(75,192,192,1)",
    //                 borderCapStyle: 'butt',
    //                 borderDash: [],
    //                 borderDashOffset: 0.0,
    //                 borderJoinStyle: 'miter',
    //                 pointBorderColor: "rgba(75,192,192,1)",
    //                 pointBackgroundColor: "#fff",
    //                 pointBorderWidth: 1,
    //                 pointHoverRadius: 5,
    //                 pointHoverBackgroundColor: "rgba(75,192,192,1)",
    //                 pointHoverBorderColor: "rgba(220,220,220,1)",
    //                 pointHoverBorderWidth: 2,
    //                 pointRadius: 1,
    //                 pointHitRadius: 10,
    //                 spanGaps: false,
    //             }
    //         ]
    //     };

    //     let options = {
    //       scales: {
    //         yAxes: [{
    //           ticks: {
    //             beginAtZero: true
    //           }
    //         }],
    //         xAxes: [{
    //             ticks: {
    //                 autoSkip: true,
    //                 maxTicksLimit: 5
    //             }
    //         }]
    //       },
    //       legend: {
    //         display: false
    //       },
    //       responsive: false
    //     };

    //     this.canvas = this.heightElement.nativeElement;
    //     this.ctx = this.canvas.getContext('2d');

    //     this.heightChart = this.createChart(this.heightElement.nativeElement.getContext('2d'), chartType, data, options);
        
    // }

    createChart(ctx, type, data, options) {
        var chart = new Chart(ctx, {
            type: type,
            data: data,
            options: options
        });
        return chart;
    }

}

