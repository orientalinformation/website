import { Component } from '@angular/core';
import { NavController, Platform, ActionSheetController, PopoverController } from 'ionic-angular';
import { AuthService } from '../../providers/auth-service';
import { Storage } from '@ionic/storage';
import { LoginPage } from '../login/login';
import { PopoverPage } from '../popover/popover';
/**
 * Generated class for the Register page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@Component({
  selector: 'page-navigator',
  templateUrl: 'navigator.html',
  inputs: ['title', 'addBack', 'addMenu']
})
export class NavigatorPage {

    constructor(
        public nav: NavController, 
        public platform: Platform,
        public actionsheetCtrl: ActionSheetController,
        public auth: AuthService,
        public popoverCtrl: PopoverController,
        public storage: Storage) {

    }

    goToBack() {
        this.nav.pop();
    }


    openPopover(myEvent) {
        let popover = this.popoverCtrl.create(PopoverPage);
        popover.present({
          ev: myEvent
        });
    }

    openMenu() {
        let actionSheet = this.actionsheetCtrl.create({
          cssClass: 'action-sheets-basic-page',
          buttons: [
            {
              text: 'Logout',
              icon: !this.platform.is('ios') ? 'log-out' : null,
              handler: () => {
                this.storage.ready().then(() => {
                    this.storage.get('id_token').then((val) => {
                        this.auth.logout(val).subscribe(succ => {
                            this.storage.remove("id_token");
                            this.nav.setRoot(LoginPage)
                        });
                    })
                });
              }
            }
          ]
        });
        actionSheet.present();
    }

}
