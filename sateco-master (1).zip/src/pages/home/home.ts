import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AuthService } from '../../providers/auth-service';
import { DataService } from '../../providers/data-service';
import { SitePage } from '../site/site';
import { Storage } from '@ionic/storage';
import { Http } from '@angular/http';

declare var google;

@Component({
  selector: 'home-page',
  templateUrl: 'home.html'
})


export class HomePage {

  @ViewChild('map') mapElement: ElementRef;
  map: any;
  public site_id;
  
  constructor(public http: Http, private nav: NavController, private auth: AuthService, public storage: Storage, public dataservice: DataService) {
    this.storage.ready().then(() => {
       this.storage.get('id_token').then((val) => {
         this.dataservice.getSites(val);

         let listSites = this.dataservice.getSitesInfo();
         listSites.sites.subscribe(data => {
            for (var i = 0; i < data.sites.length; i++) {
              this.createMarker(this.map, this.nav, data.sites[i]);
            }
          }, error => {
              console.log("Oooops!");
          });
       })
     });
  }

  ionViewDidLoad(){
    this.loadMap();
    // let service = new google.maps.places.PlacesService(this.map);
    // this.getSites(this.map, this.nav);
  }

  loadMap(){

      let vietnam = {lat: 10.8433346, lng: 106.6395545};
 
      let mapOptions = {
        center: vietnam,
        zoom: 15,
        styles: [
            {
              featureType: 'poi',
              stylers: [
                {
                  visibility: "off"
                }
              ]
            },
            {
              featureType: 'transit',
              stylers: [
                {
                  visibility: "off"
                }
              ]
            }
        ],
        disableDoubleClickZoom: true,
        mapTypeControl: false,
        scaleControl: false,
        scrollwheel: true,
        panControl: true,
        streetViewControl: false,
        draggable: true,
        overviewMapControl: false,
        mapTypeId: 'roadmap',
        overviewMapControlOptions: {
        opened: false,
        }
      }
      this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
      
  };

  createMarker(map, nav, site) {
    var myLatlng = new google.maps.LatLng(parseFloat(site.lat),parseFloat(site.lng));
    let marker = new google.maps.Marker({
        position: myLatlng,
        map: map,
        title: site.name,
        address: site.address,
        id: site.id
    });
    let infowindow = new google.maps.InfoWindow();

    marker.addListener('mouseover', function() {
      var html = "<b>Name: </b>"+ marker.title +"<br><b>Address: </b>" + marker.address ;
      infowindow.setContent(html);
      infowindow.open(map, marker);
    });

    marker.addListener('mouseout', function() {
        infowindow.close();
    });

    marker.addListener('click', function() {
      nav.push(SitePage, {
        site_id: marker.id
      });
    });
  }

}
