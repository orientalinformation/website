import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { BanchePage } from '../banche/banche';
import { PressurePage } from '../pressure/pressure';
import { DistancePage } from '../distance/distance';
import { Storage } from '@ionic/storage';
import { Http } from '@angular/http';
import { DataService } from '../../providers/data-service';
import { ChartService } from '../../providers/chart-service';


@Component({
    selector: 'page-tabs',
    templateUrl: 'tabs.html'
})
export class TabsPage {

    tab1Root = BanchePage;
    tab2Root = PressurePage;
    tab3Root = DistancePage;
    public banche;

    constructor(public params: NavParams, public nav: NavController, public dataservice: DataService, public chartservice: ChartService, public storage: Storage) {
  
        this.banche = this.params.data;
    }

   
}
