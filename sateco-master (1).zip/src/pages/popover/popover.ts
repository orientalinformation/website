import { Component } from '@angular/core';
import { NavController, ViewController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { AuthService } from '../../providers/auth-service';
import { LoginPage } from '../login/login';

@Component({
    selector: 'page-popover',
    templateUrl: 'popover.html'
})

export class PopoverPage {

constructor(public viewCtrl: ViewController, public storage: Storage, public auth: AuthService, public nav: NavController) {}

    close() {
        this.viewCtrl.dismiss();
    }

    logout() {
        this.storage.ready().then(() => {
            this.storage.get('id_token').then((val) => {
                this.auth.logout(val).subscribe(succ => {
                    this.storage.remove("id_token");
                    this.nav.push( LoginPage );
                });
            })
        });
    }
}
