import { Component, ViewChild, Directive, ElementRef } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { Http } from '@angular/http';
import { Chart } from 'chart.js';
import { ChartsModule } from 'ng2-charts';
import { AuthService } from '../../providers/auth-service';
import { DataService } from '../../providers/data-service';
import { ChartService } from '../../providers/chart-service';
/**
 * Generated class for the Register page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@Component({
  selector: 'page-banche',
  templateUrl: 'banche.html',
})
export class BanchePage {

    public thickness;
    public roll;
    public pitch;
    public height;
    public pressure;
    tabBarElement: any;

    constructor(public chartservice: ChartService, public params: NavParams, public http: Http, public nav: NavController, private auth: AuthService, public storage: Storage, public dataservice: DataService) {
        var that = this;
        setInterval(function() {
            console.log(params);
            var banche_id = params.get("banche").id;
            that.storage.ready().then(() => {
               that.storage.get('id_token').then((token) => {
                    let currentReading = that.chartservice.getThicknessRollPitch(token, banche_id, that.dataservice);
                    currentReading.reading.subscribe(data => {
                        
                        that.thickness = that.checkNull(data.reading.thickness);
                        that.pressure = that.checkNull(data.reading.pressure);
                        that.height = that.checkNull(data.reading.height);
                        that.roll = that.checkNull(data.reading.roll);
                        that.pitch = that.checkNull(data.reading.pitch);
                    });
               });
            });
        }, 1000);

        if (document.querySelector('.tabbar')) {
            this.tabBarElement = document.querySelector('.tabbar.show-tabbar');
        }
    }

    checkNull(data) {
        if (data == null) {
            return "No Data";
        } else {
            return data;
        }
    }

    ionViewWillEnter() {
        if (this.tabBarElement) {
           this.tabBarElement.style.display = 'none';
        }
    }

    ionViewWillLeave() {
        if (this.tabBarElement) {
          this.tabBarElement.style.display = 'flex';
        }

    }
    
}
