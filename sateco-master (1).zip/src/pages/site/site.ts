import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { AuthService } from '../../providers/auth-service';
import { Storage } from '@ionic/storage';
import { Http } from '@angular/http';
import { DataService } from '../../providers/data-service';
import { BanchePage } from '../banche/banche';
import { TabsPage } from '../tabs/tabs';

declare var google;

@Component({
  selector: 'page-site',
  templateUrl: 'site.html'
})


export class SitePage {

  public site_name;
  public listBanches;

  constructor(public params: NavParams, public http: Http, public nav: NavController, private auth: AuthService, public storage: Storage, public dataservice: DataService) {
    
  }
  ionViewDidLoad(){
    let site_id = this.params.get("site_id");
    this.storage.ready().then(() => {
       this.storage.get('id_token').then((val) => {
            this.dataservice.getSite(val, site_id);
            let currentSite = this.dataservice.getSiteInfo();
            currentSite.site.subscribe(data => {
                this.site_name = data.site.name;
            });

            this.dataservice.getBanches(val, site_id);
            let currentBanches = this.dataservice.getBanchesInfo();
            currentBanches.banches.subscribe(data => {
                this.listBanches = data.banches;
            });
       });
    });
  }
  openPage(data) {
    this.nav.push(TabsPage, {
      banche: data
    });
  }
  
}
