import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { HttpModule } from '@angular/http';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { LoginPage } from '../pages/login/login';
import { SitePage } from '../pages/site/site';
import { BanchePage } from '../pages/banche/banche';
import { NavigatorPage } from '../pages/navigator/navigator';
import { PopoverPage } from '../pages/popover/popover';
import { TabsPage } from '../pages/tabs/tabs';
import { PressurePage } from '../pages/pressure/pressure';
import { DistancePage } from '../pages/distance/distance';

import { AuthService } from '../providers/auth-service';
import { DataService } from '../providers/data-service';
import { ChartService } from '../providers/chart-service';
import { RegisterPage } from '../pages/register/register';
import { IonicStorageModule } from '@ionic/storage';
import { GoogleMaps } from '@ionic-native/google-maps';
import { ChartsModule } from 'ng2-charts';


@NgModule({
  declarations: [
    MyApp,
    HomePage,
    LoginPage,
    SitePage,
    BanchePage,
    RegisterPage,
    NavigatorPage,
    PopoverPage,
    TabsPage,
    PressurePage,
    DistancePage
  ],
  imports: [
    HttpModule,
    BrowserModule,
    ChartsModule,
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot()
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    LoginPage,
    SitePage,
    BanchePage,
    RegisterPage,
    NavigatorPage,
    PopoverPage,
    TabsPage,
    PressurePage,
    DistancePage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    AuthService,
    DataService,
    GoogleMaps,
    ChartService,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
