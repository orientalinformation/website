<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require 'vendor/autoload.php';
require 'database.php';

$app = new \Slim\App;

$prefix = "/api/v1";

$app->post($prefix.'/user/login', function($request) {

	$data['username'] = $_POST['username'];
	$data['password'] = $_POST['password'];

	$user = getUser($data);
	$password = $user['passsalt'].$data['password'].$user['passsalt'];
	$password = hash('sha512', $password);

	if ($user['password'] == $password) {
		$response['status'] = true;
		$response['username'] = $user['username'];
		$response['token'] = createToken($user['id']);
		alertResult($response);
	} else {
		$response['status'] = false;
		alertResult($response);
	}
});

$app->get($prefix.'/user/logout', function($request) {

    $headers = apache_request_headers();
    $path = "token/".$headers['Authorization'];
    unlink($path);

	$response['status'] = true;
	alertResult($response);

});

$app->get($prefix.'/sites', function($request) {   
    $data = getUserIdByToken();   

    $user = getUser($data);
    $data['company_id'] = $user['company_id'];
    $sites = getSites($data);

    $response['status'] = true;
    $response['sites'] = $sites;
    alertResult($response);
});

$app->get($prefix.'/site/{id}', function ($request) {
    $data = getUserIdByToken();   

    $data['site_id'] = $request->getAttribute('id');
    $site = getSite($data);
    $response['status'] = true;
    $response['site'] = $site;
    alertResult($response);
});

$app->get($prefix.'/banches/{site_id}', function ($request) {
    $data = getUserIdByToken();   

    $data['site_id'] = $request->getAttribute('site_id');
    $banches = getBanches($data);

    $response['status'] = true;
    $response['banches'] = $banches;
    alertResult($response);
});

$app->get($prefix.'/banche/{id}', function ($request) {
    $data = getUserIdByToken();   

    $data['banche_id'] = $request->getAttribute('id');
    $banche = getBanche($data);

    $response['status'] = true;
    $response['banche'] = $banche;
    alertResult($response);
});

$app->get($prefix.'/readings/{banche_id}', function ($request) {
    $data = getUserIdByToken();   

    $data['banche_id'] = $request->getAttribute('banche_id');
    $now = time();
    $data['from'] = date("Y-m-d H:i:s", ($now - 60*60*8));
    $data['to'] = date("Y-m-d H:i:s", $now);
    
    $readings = getReadings($data);

    $response['status'] = true;
    $response['readings'] = $readings;
    alertResult($response);
});

$app->get($prefix.'/readings/{banche_id}/{from}', function ($request)  {
    $data = getUserIdByToken();   

    $data['banche_id'] = $request->getAttribute('banche_id');
    $data['from'] = date("Y-m-d H:i:s", $request->getAttribute('from'));
    $data['to'] = date("Y-m-d H:i:s", time());

    $readings = getReadings($data);

    $response['status'] = true;
    $response['readings'] = $readings;
    alertResult($response);
});

$app->get($prefix.'/readings/{banche_id}/{from}/{to}', function ($request) {
    $data = getUserIdByToken();   

    $data['banche_id'] = $request->getAttribute('banche_id');
    $data['from'] = date("Y-m-d H:i:s", $request->getAttribute('from'));
    $data['to'] = date("Y-m-d H:i:s", $request->getAttribute('to'));    

    $readings = getReadings($data);

    $response['status'] = true;
    $response['readings'] = $readings;
    alertResult($response);
});

$app->post($prefix.'/readings/new/{banche_id}', function ($request) {

    $data['banche_id'] = $request->getAttribute('banche_id');
    $data['pressure'] = $_POST['pressure'];
    $data['thickness'] = $_POST['thickness'];
    $data['height'] = $_POST['height'];
    $data['roll'] = $_POST['roll'];
    $data['pitch'] = $_POST['pitch'];

    
    $response['status'] = insertReading($data);
    alertResult($response);

});

$app->get($prefix.'/reading/{banche_id}', function ($request) {
    $data = getUserIdByToken();   

    $data['banche_id'] = $request->getAttribute('banche_id');
    $reading = getLastReading($data);

    $response['status'] = true;
    $response['reading'] = $reading;
    alertResult($response);
});

$app->get($prefix.'/reading/{banche_id}/{last_id}', function ($request) {
    $data = getUserIdByToken();   

    $data['banche_id'] = $request->getAttribute('banche_id');
    $data['last_id'] = $request->getAttribute('last_id');
    $reading = getRealTimeReading($data);

    $response['status'] = true;
    $response['reading'] = $reading;
    alertResult($response);
});

$app->get($prefix.'/devices/{banche_id}', function ($request) {
    $data = getUserIdByToken();   

    $data['banche_id'] = $request->getAttribute('banche_id');
    $devices = getDevices($data);

    $response['status'] = true;
    $response['devices'] = $devices;
    alertResult($response);
});

$app->post($prefix.'/user/create', function($request) {
    $data = getUserIdByToken();   
    
	$data['username'] = $_POST['username'];
	$data['passsalt'] = generatePassSalt(10);
	$data['password'] = $data['passsalt'].$_POST['password'].$data['passsalt'];
	$data['password'] = hash('sha512', $data['password']);
	$data['email'] = $_POST['email'];
	$data['company_id'] = $_POST['company_id'];
	$data['role_id'] = $_POST['role_id'];
	

	$response['status'] = insertUser($data);
	alertResult($response);

});


$app->post($prefix.'/user/forgot_password', function($request) {

	$data['id'] = $_POST['id'];
	$data['username'] = $_POST['username'];
	$data['passsalt'] = generatePassSalt(10);
	$data['password'] = $data['passsalt'].$_POST['password'].$data['passsalt'];
	$data['password'] = hash('sha512', $data['password']);

	updateUser($data);

	$response['status'] = true;
	alertResult($response);

});	

$app->post($prefix.'/user/delete', function($request) {

	$data['id'] = $_POST['id'];

	deleteSite($data);

	$response['status'] = true;
	alertResult($response);
	
});

$app->post($prefix.'/company/new', function($request) {

	$data['nameCompany'] = $_POST['nameCompany'];
	$data['addrCompany'] = $_POST['addrCompany'];

	insertCompany($data);

	$response['status'] = true;
	alertResult($response);
	
});


$app->post($prefix.'/site/new', function($request) {

	$data['name'] = $_POST['name'];
	$data['address'] = $_POST['address'];
    $data['lat'] = $_POST['lat'];
	$data['lng'] = $_POST['lng'];
	$data['company_id'] = $_POST['company_id'];

	$response['status'] = insertSite($data);
	alertResult($response);
	
});


$app->post($prefix.'/deleteSite', function($request) {

	$data['id'] = $_POST['idSite'];

	deleteSite($data);
	
});

$app->post($prefix.'/insertBanche', function($request) {

	$data['pressure'] = $_POST['pressure'];
	$data['alignment'] = $_POST['alignment'];
	$data['distance'] = $_POST['distance'];
	$data['site_id'] = $_POST['site_id'];
	$data['created'] = date('Y-m-d H:i:s');

	insertBanche($data);
	
});

$app->post($prefix.'/deleteBanche', function($request) {

	$data['fromDate'] = $_POST['fromDate'];
	$data['toDate'] = $_POST['toDate'];
	$data['site_id'] = $_POST['site_id'];

	deleteBanche($data);
	
});

$app->run();

function generatePassSalt($length)
{
	$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()"; 
	$size = strlen( $chars );
	$str = '';
	for( $i = 0; $i < $length; $i++ ) {
		$str .= $chars[ rand( 0, $size - 1 ) ];
	}
	return $str;
}

function alertResult($response)
{
	echo json_encode($response);
	die();
}

function createToken($id)
{
    do{
        $token = md5(rand());   
        $path = "token/".$token;
    }while(file_exists($path));
	file_put_contents($path, $id);

	return $token;
}

function checkToken($token)
{
    $path = "token/";
    $file = $path.$token;
    if (file_exists($file)) {
        $data = file_get_contents($file);
        return $data;
    } else {
        $response['status'] = false;
        alertResult($response);
    }
}

function getUserIdByToken()
{
    $headers = apache_request_headers();
    $data['user_id'] = checkToken($headers['Authorization']);

    if (empty($data['user_id'])) {
        $response['status'] = false;
        alertResult($response);
    }

    return $data;
}