import { Component } from '@angular/core';
import { AlertController, Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Serial } from '@ionic-native/serial';
import { SerialService } from '../providers/serial-service';
import { AuthService } from '../providers/auth-service';
import { DbService } from '../providers/db-service';
import { GoogleMaps } from '@ionic-native/google-maps';

// import { TabsPage } from '../pages/tabs/tabs';
import { LoginPage } from '../pages/login-page/login-page';

// declare var navigator: any;
// declare var Connection: any;
// declare function escape(s:string): string;
// declare function unescape(s:string): string;

@Component({
  providers:[SerialService],
  templateUrl: 'app.html'
})
export class MyApp {
  // rootPage:any = TabsPage;
  rootPage:any = LoginPage;
  // private anyErrors: string;
  // private finished: boolean;
  // private errorInfo: string;
  // private dataRespone: string;

  constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen,serial: Serial, 
    alertCtrl: AlertController, serialService:SerialService, googlemaps: GoogleMaps,
    public dbService: DbService) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleDefault();
      serialService.open();
      splashScreen.hide();

      

    });
    // this.checkNetwork();
  }

  // checkNetwork() {
    //     var serialOptions = {
      //         baudRate: 115200,
      //         dtr: true,
      //         rts: true
      //     };

      //         this.serial.requestPermission({
        //           vid: '2341',
        //             pid: '8036',
        //             driver: 'CdcAcmSerialDriver'
        //         }).then(() => {
          //         this.serial.open(serialOptions).then(() => {
            //         this.serial.registerReadCallback().subscribe(
            //           x => {
              //             var result = "";
              //             var dat = new Uint8Array(x);
              //             for(var i in dat){
                //               result += unescape(escape(String.fromCharCode(dat[i])));
                //             }
                //             if (typeof result != 'undefined' && result != null && result != "") {
                  //               this.dataRespone += " | " + result + " ----- ";
                  //               result = "";
                  //             }
                  //           },
                  //           error => this.anyErrors = error,
                  //                 () => this.finished = true
                  //         );
                  //         // for (var i = 100; i >= 0; i--) {
                    
                    //         // }
                    //       }).catch((error: any) => this.errorInfo = "open serial" + error);
                    //     }).catch((error: any) => this.errorInfo = "requestPermission" + error);
                    //     let intervalId = setInterval(() => {  
                      //       this.serial.write("aaaa");
                      //     }, 30000);
                      
                      //   }
                    }
