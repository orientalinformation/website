import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { App, MenuController, IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { Serial } from '@ionic-native/serial';
import {File} from '@ionic-native/file';
import { HttpModule } from '@angular/http';
import { IonicStorageModule } from '@ionic/storage';
import { GoogleMaps, GoogleMap, GoogleMapsEvent, LatLng, CameraPosition, MarkerOptions, Marker } from '@ionic-native/google-maps';

//SATECO service
import { DbService } from '../providers/db-service';
import { SerialService } from '../providers/serial-service';
import { AuthService } from '../providers/auth-service';
import { SitesService } from '../providers/sites-service';
import { BanchesService } from '../providers/banches-service';
import { DevicesService } from '../providers/devices-service';
import { ReadingsService } from '../providers/readings-service';
import { CommonService } from '../providers/common-service';
import { ChartService } from '../providers/chart-service';

import { MyApp } from './app.component';

import { AboutPage } from '../pages/about/about';
import { ContactPage } from '../pages/contact/contact';
import { HomePage } from '../pages/home/home';
import { SettingsPage } from '../pages/settings-page/settings-page';
import { LoginPage } from '../pages/login-page/login-page';
import { SitePage } from '../pages/site-page/site-page';
import { CalibzeroPage } from '../pages/calibzero-page/calibzero-page';
import { CalibpointPage } from '../pages/calibpoint-page/calibpoint-page';
import { TolerancePage } from '../pages/tolerance-page/tolerance-page';
import { ValeurMaxPage } from '../pages/valeur-max-page/valeur-max-page';
import { DistancePage } from '../pages/distance/distance';
import { PressurePage } from '../pages/pressure/pressure';
import { TabsPage } from '../pages/tabs/tabs';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

@NgModule({
  declarations: [
    MyApp,
    LoginPage,
    AboutPage,
    ContactPage,
    HomePage,
    SettingsPage,
    SitePage,
    CalibzeroPage,
    CalibpointPage,
    TolerancePage,
    ValeurMaxPage,
    DistancePage,
    PressurePage,
    TabsPage
  ],
  imports: [
    BrowserModule,
    HttpModule,
    IonicStorageModule.forRoot({
      name: '__satecodb',
      driverOrder: ['indexeddb', 'sqlite', 'websql']
    }),
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    LoginPage,
    AboutPage,
    ContactPage,
    HomePage,
    SettingsPage,
    SitePage,
    CalibzeroPage,
    CalibpointPage,
    TolerancePage,
    ValeurMaxPage,
    DistancePage,
    PressurePage,
    TabsPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    Serial,
    File,
    SerialService,
    AuthService,
    GoogleMaps,
    DbService,
    App,
    SitesService,
    BanchesService,
    DevicesService,
    ReadingsService,
    CommonService,
    ChartService,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
