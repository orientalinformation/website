import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import { Headers, Http, Request, RequestOptions, RequestMethod } from '@angular/http';
import 'rxjs/add/operator/map';
import { Storage } from '@ionic/storage';
import {CommonService} from './common-service';


export class User {
  username: string;
  password: string;
  token: string;
  roleId: number;

  constructor(username: string, password: string, token: string, roleId: number) {
    this.username = username;
    this.password = password;
    this.token = token;
    this.roleId = roleId;
  }
}

export class UserRemember{
  username: string;
  password: string;

  constructor(username: string, password: string) {
    this.username = username;
    this.password = password;
  }
}

@Injectable()
export class AuthService {
  users: Array<User> = [];
  currentUser: User;
  currentUserRemember: UserRemember;

  constructor(public http: Http, public storage: Storage, public commonService: CommonService) {
    storage.ready().then(() => {
      // Or to get a key/value pair
      storage.get('users').then( data => {
        if (data == null)
          this.users = [];
        else{
          this.users = JSON.parse(data);
        }
      }).catch((error: any) => {
        storage.set('users', '[]');
        this.users = [];
      });
    });
  }

  public getUserRemember(){
    return Observable.create(observer => {
      this.storage.ready().then(() => {
        this.storage.get('user_remember').then( data => {
          this.currentUserRemember = JSON.parse(data);
          observer.next(this.currentUserRemember);
          observer.complete();
        });
      });
    });
  }

  public login(credentials) {
    var link = this.commonService.host + this.commonService.login_api;
    let body = new FormData();
    body.append('username', credentials.username);
    body.append('password', credentials.password);
    if ( credentials.remember ){
      this.currentUserRemember = new UserRemember(credentials.username, credentials.password);
      this.storage.set('user_remember', JSON.stringify(this.currentUserRemember));  
    }
    if (credentials.username === null || credentials.password === null) {
      return Observable.throw(this.commonService.err_login);
    } else {
      if (this.commonService.checkNetwork()) {
        return Observable.create(observer => {
          // At this point make a request to your backend to make a real check!
          this.http.post(link, body).map(res => res.json()).subscribe(data => {
            var access = [data.status, data.token];
            if (access[0]){
              this.currentUser = new User(data.username, credentials.password, data.token, data.role_id);
              let isExist = false;
              for ( let user of this.users ) {
                if (user.username == credentials.username) {
                  user.password = credentials.password;
                  isExist = true;
                }
              }
              if (!isExist)
                this.users.push(this.currentUser);

              this.storage.set('users', JSON.stringify(this.users));  
            }
            observer.next(access);
            observer.complete();
          });
        });
      }else{
        return Observable.create(observer => {
          for ( let _userIndex in this.users ) {
            if (this.users[_userIndex].username.toLowerCase() == credentials.username.toLowerCase() && 
              this.users[_userIndex].password.toLowerCase() == credentials.password.toLowerCase()) 
            {
              var access = ["true", this.users[_userIndex].token];
              this.currentUser = this.users[_userIndex];
              observer.next(access);
              observer.complete();
            }
          }
        });

      }
    }
  }

  public getUserInfo() : User {
    return this.currentUser;
  }

  public logout() {
    return Observable.create(observer => {
      var headers = new Headers();

      headers.append('Authorization', this.currentUser.token);

      var link = this.commonService.host + this.commonService.logout_api;

      let options = new RequestOptions({
        method: RequestMethod.Get,
        url: link,
        headers: headers
      });
      this.http.request(new Request(options))
      .map(res => res.json())
      .subscribe(data => {
        let access = data.status;
        this.currentUser = null;
        observer.next(access);
        observer.complete();
      }, error => {
        console.log("Logout error");
      });
    });
  }

}
