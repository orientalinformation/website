import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { ToastController } from 'ionic-angular';

/*
  Generated class for the CommonService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
  	*/

  declare var navigator: any;
  declare var Connection: any;
  
  @Injectable()
  export class CommonService {

  	public readonly host = "http://public.dfm-engineering.com/sateco";

  	public readonly sites_dbName: string = "__sites";
  	public readonly banches_dbName: string = "__banches";
  	public readonly devices_dbName: string = "__devices";
  	public readonly readings_dbName: string = "__readings";

    public readonly login_api: string = '/api/v1/user/login';
    public readonly logout_api: string = '/api/v1/user/logout';
    public readonly sites_api: string = '/api/v1/sites';
  	public readonly site_api: string = '/api/v1/site';
    public readonly devices_api: string = '/api/v1/devices';
    public readonly banches_api: string = '/api/v1/banches';
    public readonly getReadings_api: string = '/api/v1/readings';
  	public readonly setReadings_api: string = '/api/v1/readings/new';

    public readonly fncCalibZero: string = "calib-zero";
    public readonly fncCalibPoint: string = "calib-point";
    public readonly fncSetTol: string = "set-step";
    public readonly fncSetMax: string = "set-max";

    public readonly err_notConnect = "Pas connecté";
    public readonly err_login = "Nom d'utilisateur ou mot de passe est incorrect";

  	public driverOrder: Array<string> = ['indexeddb', 'sqlite', 'websql'];

    public isConnected = false;

    public bancheId;
    public pressionVal;
    public heightVal;
    public created;
    public isResponse;

  	constructor(public http: Http, public toastCtrl: ToastController) {
  		console.log('Hello CommonService Provider');
  	}

    showToast(msg){
        let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'top'
        });
        toast.present();
    }

    public checkNetwork(): boolean {
      var networkState = navigator.connection.type;
        var states = {};
        states[Connection.UNKNOWN]  = 'Unknown connection';
        states[Connection.ETHERNET] = 'Ethernet connection';
        states[Connection.WIFI]     = 'WiFi connection';
        states[Connection.CELL_2G]  = 'Cell 2G connection';
        states[Connection.CELL_3G]  = 'Cell 3G connection';
        states[Connection.CELL_4G]  = 'Cell 4G connection';
        states[Connection.CELL]     = 'Cell generic connection';
        states[Connection.NONE]     = 'No network connection';
        console.log("states[networkState]" + states[networkState]);
        if (states[networkState] == "No network connection" || states[networkState] == "Unknown connection")
          return false;
        return true;
    }

  }
