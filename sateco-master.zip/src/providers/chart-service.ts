import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Headers, Http, Request, RequestOptions, RequestMethod } from '@angular/http';
import { Storage } from '@ionic/storage';

import { Chart } from 'chart.js';
/*
  Generated class for the GetData provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
    */

  export class Reading {
    reading: any;
    constructor(reading) {
      this.reading = reading;
    }
  }

  export class Readings {
    readings: any;
    constructor(readings) {
      this.readings = readings;
    }
  }
  @Injectable()
  export class ChartService {

    public host = "http://public.dfm-engineering.com/sateco";
    public prefix = "/api/v1";
    currentReading: Reading;
    currentReadings: Readings;

    constructor(public http: Http, public storage: Storage) {
    }

    getThicknessRollPitch(token, banche_id) {
      this.getReading(token, banche_id);
      let currentReading = this.getReadingInfo();
      currentReading = this.getReadingInfo();
      return currentReading;
    }

    public getReadingInfo() : Reading {
      return this.currentReading;
    }

    public getReadingsInfo() : Readings {
      return this.currentReadings;
    }


    public getReading(token, banche_id) {
      var headers = new Headers();
      headers.append('Authorization', token);

      var link = this.host + this.prefix + '/reading/' + banche_id;
      let options = new RequestOptions({
        method: RequestMethod.Get,
        url: link,
        headers: headers
      });
      this.currentReading = new Reading(this.http.get(link, options).map(res => res.json())); 
    }

    public _getDataTimeNow(token, banche_id) {
      var headers = new Headers();
      headers.append('Authorization', token);

      var link = this.host + this.prefix + '/readings/' + banche_id;
      let options = new RequestOptions({
        method: RequestMethod.Get,
        url: link,
        headers: headers
      });
      this.currentReadings = new Readings(this.http.get(link, options).map(res => res.json())); 
    }

    getDataTimeNow(token, banche_id, chart, dataDraw) {

      var arrDatas = [];
      var arrLabels = [];
      var last_id;
      this._getDataTimeNow(token, banche_id);
      let currentReadings = this.getReadingsInfo();
      currentReadings.readings.subscribe(data => {
        data = JSON.stringify(data);
        console.log(" data.reading : " + data);
          console.log(" data.reading : " + JSON.stringify(data));
        if (data.readings.length != 0) {
          for (let reading of data.readings) {
            if (dataDraw == "pressure") {
              if (reading.pressure != null) {
                let arrDatetime = reading.created.split(" ");
                arrLabels.push(arrDatetime[1]);
                arrDatas.push(reading.pressure);
                last_id = reading.id;
              }
            }

            if (dataDraw == "height") {
              if (reading.height != null) {
                let arrDatetime = reading.created.split(" ");
                arrLabels.push(arrDatetime[1]);
                arrDatas.push(reading.height);
                last_id = reading.id;
              }
            }

          }
          chart.data.datasets[0].data = arrDatas;
          chart.data.labels = arrLabels;
          chart.update();

          this.getDataRealTime(token, banche_id, last_id, chart, dataDraw);
        } else {
          this.getReading(token, banche_id);
          let currentReading = this.getReadingInfo();
          currentReading.reading.subscribe(data => {
            last_id = data.reading.id;
            this.getDataRealTime(token, banche_id, last_id, chart, dataDraw);
          });
        }
      });
    }

    public getDataRealTimeReading(token, banche_id, last_id) {
      var headers = new Headers();
      headers.append('Authorization', token);

      var link = this.host + this.prefix + '/reading/' + banche_id + "/" + last_id;
      let options = new RequestOptions({
        method: RequestMethod.Get,
        url: link,
        headers: headers
      });
      this.currentReadings = new Readings(this.http.get(link, options).map(res => res.json())); 
    }

    getDataRealTime(token, banche_id, last_id, chart, dataDraw) {
      var that = this;

      setInterval(function() {
        that.getDataRealTimeReading(token, banche_id, last_id);
        let currentReadings = that.getReadingsInfo();
        currentReadings.readings.subscribe(data => {
          
          if (data.reading.length != 0) {
            for (let reading of data.reading) {
              if (dataDraw == "pressure") {
                if (reading.pressure != null) {
                  let arrDatetime = reading.created.split(" ");
                  chart.data.labels.push(arrDatetime[1]);
                  chart.data.datasets[0].data.push(reading.pressure);
                  last_id = reading.id;
                  if (chart.data.labels.length >= 20) {
                    chart.data.labels.shift();
                    chart.data.datasets[0].data.shift();
                  }
                }
              }
              if (dataDraw == "height") {
                if (reading.height != null) {
                  let arrDatetime = reading.created.split(" ");
                  chart.data.labels.push(arrDatetime[1]);
                  chart.data.datasets[0].data.push(reading.height);
                  last_id = reading.id;
                }
              }
            }
            chart.update();
          }
        });
      }, 5000);
    }

    createChart(ctx, type, data, options) {
      var chart = new Chart(ctx, {
        type: type,
        data: data,
        options: options
      });
      return chart;
    }

  }

