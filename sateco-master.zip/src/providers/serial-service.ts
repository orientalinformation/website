import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Serial } from '@ionic-native/serial';
import { Observable } from 'rxjs';
import {CommonService} from './common-service';
import {DbService} from './db-service';


import 'rxjs/add/operator/map';

declare function escape(s:string): string;
declare function unescape(s:string): string;

@Injectable()
export class SerialService {

    public currentSites: Array<any> = [];
    public currentBanches: Array<any> = [];
    public currentDevices: Array<any> = [];
    public currentBancheId: string;
    public currentSerialNumber: string;

    constructor(public http: Http, private serial: Serial, public dbService: DbService,
        public commonService: CommonService) {
    }

    getAllDatabase(loginToken){
        //Get Sites
        if ( this.commonService.checkNetwork() ) {
            this.dbService.getSites(loginToken).subscribe(sites => {
                for (let _siteIndex in sites){
                    this.currentSites.push(sites[_siteIndex]);
                    //Get Banches
                    this.dbService.getBanches(loginToken, sites[_siteIndex].id).subscribe(banches => {
                        for (let _banchesIndex in banches){
                            this.currentBanches.push(banches[_banchesIndex]);
                            //Get Devices
                            this.dbService.getDevices(loginToken, banches[_banchesIndex].id).subscribe(devices => {
                                this.currentDevices = devices;
                                this.listenRespone();
                            }, error => {
                            });
                        }
                    }, error => {
                    })
                }
            },error => {
            });
        }
        this.dbService.setSites(this.currentSites);
        this.dbService.setBanches(this.currentBanches);
        this.dbService.setDevices(this.currentDevices);
    }

    // readSerialByBancheId(bancheId, lblPression: HTMLElement, lblThickNess: HTMLElement,
    //     lblHeight: HTMLElement, lblRoll: HTMLElement, lblPitch: HTMLElement ) {
        readSerialByBancheId(bancheId, lblPression: HTMLElement ) {
            this.readyRead().subscribe(data => {
                let result = "";
                let view = new Uint8Array(data);
                let date = new Date();
                let minutes = date.getMinutes();
                let hours = date.getHours();
                let seconds = date.getSeconds();

                let created = hours + ":" + minutes + ":" + seconds;
                for(var i in view){
                    if(view[i] == 13 || view[i] == 10){
                        let dtResult = result.replace(/\r?\n/g, "").split(" ");
                        let serialNumber = dtResult[0];
                        let devicePart = serialNumber.substr(2,1);
                        if(this.checkBancheId(dtResult, bancheId, serialNumber)){
                            if (devicePart == "P"){
                                lblPression.innerHTML = dtResult[1] + " Kf";
                                this.commonService.pressionVal = dtResult[1];
                                this.commonService.created = created;
                            }
                            if (devicePart == "I"){
                                // lblRoll.innerHTML = dtResult[1];
                                // lblPitch.innerHTML = dtResult[2];
                            }
                            if (devicePart == "R"){
                                // lblThickNess.innerHTML = dtResult[1];
                                // lblHeight.innerHTML = dtResult[2];
                                this.commonService.heightVal = dtResult[2];
                                this.commonService.created = created;
                            }
                        }

                        this.resquestServer(dtResult);
                        this.commonService.isResponse = true;

                    }else{
                        result += unescape(escape(String.fromCharCode(view[i])));
                    }
                }
            },error => {
            });
        }

        resquestServer(dtResult){
            if(this.setBancheId(dtResult)){
                let dtSend = [];
                for (let index in dtResult){
                    if (index != "0")
                        dtSend.push(dtResult[index]);
                }
                this.dbService.setReading(this.currentSerialNumber, this.currentBancheId, dtSend);
            }
        }

        checkBancheId(dtRespone, bancheId, serialNumber){
            for (var _deviceIndex in this.currentDevices) {
                if ( this.currentDevices[_deviceIndex].serialNumber == serialNumber ){
                    if ( this.currentDevices[_deviceIndex].bancheId == bancheId )
                        return true;
                }
            }
            return false;
        }

        listenRespone(){
            this.readyRead().subscribe(data => {
                let result = "";
                let view = new Uint8Array(data);

                for(var i in view){
                    if(view[i] == 13 || view[i] == 10){
                        let dtResult = result.replace(/\r?\n/g, "").split(" ");
                        this.resquestServer(dtResult);
                    }else{
                        result += unescape(escape(String.fromCharCode(view[i])));
                    }
                }
            },error => {

            });
        }

        setBancheId(dtRespone): boolean{
            this.currentSerialNumber = dtRespone[0];
            for (var _deviceIndex in this.currentDevices) {
                if ( this.currentDevices[_deviceIndex].serialNumber == this.currentSerialNumber ){
                    this.currentBancheId = this.currentDevices[_deviceIndex].bancheId;
                    return true;
                }
            }
            return false;
        }

        open() {
            this.serial.requestPermission({
                vid: '2341',
                pid: '8036',
                driver: 'CdcAcmSerialDriver'
            }).then(() => {
                this.serial.open({
                    baudRate: 115200,
                    dtr: true,
                    rts: true
                }).then(() => {
                    console.log('Serial connection opened');
                });
            }).catch((error: any) => {
                this.createTimeout(1000)
                .then(() => {
                    this.open();
                })
            });
        }

        errorCallback() {

        }

        readyRead(): Observable<any> {
            return this.serial.registerReadCallback();
        }

        write(msg: string) {
            this.serial.write(msg);
        }

        writeHex(msg: any) {
            this.serial.writeHex(msg);
        }

        createTimeout(timeout) {
            return new Promise((resolve, reject) => {
                setTimeout(() => resolve(null),timeout)
            })
        }
    }
