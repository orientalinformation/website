import { Injectable } from '@angular/core';
import { Headers, Http, Request, RequestOptions, RequestMethod } from '@angular/http';
import {Observable} from 'rxjs/Observable';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map';

import {CommonService} from './common-service';

//DEVICE MODEL
export class Device {
  id: number;
  name: string;
  serialNumber: string;
  bancheId: number;
  created: string;

  constructor(id: number, name: string, serialNumber: string, bancheId: number, created: string) {
    this.id = id;
    this.name = name;
    this.serialNumber = serialNumber;
    this.bancheId = bancheId;
    this.created = created;
  }
}

/*
  Generated class for the DevicesService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
    */
  @Injectable()
  export class DevicesService {
    dbDevices: Storage;
    currentDevice: Device;
    currentDevices: Array<Device> = [];

    constructor(public http: Http, public storage: Storage,
      public commonService: CommonService) {
      this.dbDevices = new Storage({
        name: this.commonService.devices_dbName,
        driverOrder: this.commonService.driverOrder
      });

      this.dbDevices.ready().then(() => {
        // Or to get a key/value pair
        this.dbDevices.get(this.commonService.devices_dbName).then( data => {
          if (data == null)
            this.currentDevices = [];
          else{
            this.currentDevices = JSON.parse(data);
          }
        }).catch((error: any) => {
          this.dbDevices.set(this.commonService.devices_dbName, '[]');
          this.currentDevices = [];
        });
      });
    }

    setDevices(device: Array<Device>){
      this.dbDevices.set(this.commonService.devices_dbName, JSON.stringify(device));
    }

    getDevices(token: any, bancheId: any){
      var headers = new Headers();
      headers.append('Authorization', token);

      var link = this.commonService.host + this.commonService.devices_api + "/" + bancheId;
      let options = new RequestOptions({
        method: RequestMethod.Get,
        url: link,
        headers: headers
      });
      return Observable.create(observer => {
        // At this point make a request to your backend to make a real check!
        this.http.get(link, options).map(res => res.json())
        .subscribe(data => {
          //Loop data respone 
          for (let _deviceIndex in data.devices){
            //Create new site
            var deviceItem = data.devices[_deviceIndex];
            this.currentDevice = new Device(deviceItem.id, deviceItem.name,
              deviceItem.serial_number, deviceItem.banche_id, deviceItem.created);

            let isExist = false;
            
            //Loop current site on database 
            if( this.currentDevices.length < 1) {
              this.currentDevices.push(this.currentDevice);
            }
            else{
              for (var devicesIndex in this.currentDevices) {

                if( this.currentDevices[devicesIndex].id == this.currentDevice.id){
                  this.currentDevices[devicesIndex] = this.currentDevice;
                  isExist = true;
                  break;
                }else{
                  isExist = false;
                }
              }
              if( !isExist )
                this.currentDevices.push(this.currentDevice);
            }
          }
          this.setDevices(this.currentDevices);

          observer.next(this.currentDevices);
          observer.complete();
        }, error => {
          //Check username password offline
          observer.next(this.currentDevices);
          observer.complete();
        });
      });
    }
  }
