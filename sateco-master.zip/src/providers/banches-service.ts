import { Injectable } from '@angular/core';
import { Headers, Http, Request, RequestOptions, RequestMethod } from '@angular/http';
import {Observable} from 'rxjs/Observable';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map';

import {CommonService} from './common-service';

//BANCHE MODEL
export class Banche {
	id: number;
	name: string;
	status: number;
	siteId: number;
	created: string;
	lastActive: string;

	constructor(id: number, name: string, status: number, siteId: number, created: string,
		lastActive: string) {
		this.id = id;
		this.name = name;
		this.status = status;
		this.siteId = siteId;
		this.lastActive = lastActive;
		this.created = created;
	}
}

/*
  Generated class for the BanchesService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
  	*/
  @Injectable()
  export class BanchesService {
  	dbBanches: Storage;
  	currentBanche: Banche;
  	currentBanches: Array<Banche> = [];

  	constructor(public http: Http, public storage: Storage,
  		public commonService: CommonService) {
  		this.dbBanches = new Storage({
  			name: this.commonService.banches_dbName,
  			driverOrder: this.commonService.driverOrder
  		});

  		this.dbBanches.ready().then(() => {
  			// Or to get a key/value pair
  			this.dbBanches.get(this.commonService.banches_dbName).then( data => {
  				if (data == null)
  					this.currentBanches = [];
  				else{
  					this.currentBanches = JSON.parse(data);
  				}
  			}).catch((error: any) => {
  				this.dbBanches.set(this.commonService.banches_dbName, '[]');
  				this.currentBanches = [];
  			});
  		});
  	}

  	setbanches(banche: Array<Banche>){
  		this.dbBanches.set(this.commonService.banches_dbName, JSON.stringify(banche));
  	}

  	getBanches(token: any, siteId: any){
  		var headers = new Headers();
      headers.append('Authorization', token);

  		var link = this.commonService.host + this.commonService.banches_api + "/" + siteId;
  		let options = new RequestOptions({
  			method: RequestMethod.Get,
  			url: link,
  			headers: headers
  		});
  		return Observable.create(observer => {
  			// At this point make a request to your backend to make a real check!
  			this.http.get(link, options).map(res => res.json())
  			.subscribe(data => {
  				//Loop data respone 
  				for (let _bancheIndex in data.banches){
  					//Create new site
  					var bancheItem = data.banches[_bancheIndex];
  					this.currentBanche = new Banche(bancheItem.id, bancheItem.name, bancheItem.status, 
  						bancheItem.siteId, bancheItem.created, bancheItem.lastActive);

  					let isExist = false;

  					//Loop current site on database 
  					if( this.currentBanches.length < 1) {
  						this.currentBanches.push(this.currentBanche);
  					}
  					else{
  						for (var banchesIndex in this.currentBanches) {

  							if( this.currentBanches[banchesIndex].id == this.currentBanche.id){
  								this.currentBanches[banchesIndex] = this.currentBanche;
  								isExist = true;
  								break;
  							}else{
  								isExist = false;
  							}
  						}
  						if( !isExist )
  							this.currentBanches.push(this.currentBanche);
  					}
  				}
  				this.setbanches(this.currentBanches);

  				observer.next(this.currentBanches);
  				observer.complete();
  			}, error => {
  				//Check username password offline
  				observer.next(this.currentBanches);
  				observer.complete();
  			});
  		});
  	}
  }
