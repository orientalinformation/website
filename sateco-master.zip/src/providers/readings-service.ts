import { Injectable } from '@angular/core';
import { Headers, Http, Request, RequestOptions, RequestMethod } from '@angular/http';
import {Observable} from 'rxjs/Observable';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map';

import {CommonService} from './common-service';

//READING MODEL
export class Reading {
  bancheId: number;
  serialNumber: string;
  value: Array<string> = [];
  created: string;

  constructor(bancheId: number, serialNumber: string, value: Array<string>) {
    this.bancheId = bancheId;
    this.serialNumber = serialNumber;
    this.value = value;
    let date = new Date();
    let minutes = date.getMinutes();
    let hours = date.getHours();
    let seconds = date.getSeconds();

    this.created = hours + ":" + minutes + ":" + seconds;
  }
}

/*
  Generated class for the ReadingsService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
  	*/
  @Injectable()
  export class ReadingsService {
  	dbReadings: Storage;
  	currentReading: Reading;
  	currentReadings: Array<Reading> = [];
    dbIndex: number = 0;

    constructor(public http: Http, public storage: Storage,
      public commonService: CommonService) {
      this.dbReadings = new Storage({
        name: this.commonService.readings_dbName,
        driverOrder: this.commonService.driverOrder
      });
      
      this.dbReadings.ready().then(() => {
        this.dbReadings.forEach( (value, key, index) => {
          let intKey = parseInt(key);
          let dataParse = JSON.parse(value);
          if (this.dbIndex < intKey)
            this.dbIndex = parseInt(key);
        });
      });
    }

    public setReading(serialNumber, bancheId, dataArr){
      var link = this.commonService.host + this.commonService.setReadings_api;
      let body = new FormData();

      body.append('banche_id', bancheId);
      body.append('serial_number', serialNumber);
      body.append('value', dataArr);

      this.currentReading = new Reading(bancheId, serialNumber, dataArr);
      this.dbIndex += 1;
      this.dbReadings.set(String(this.dbIndex), JSON.stringify(this.currentReading));

      this.http.post(link, body).map(res => res.json())
      .subscribe(data => {
      }, error => {
      });
    }

  }
