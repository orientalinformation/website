import { Injectable } from '@angular/core';
import { Headers, Http, Request, RequestOptions, RequestMethod } from '@angular/http';
import {Observable} from 'rxjs/Observable';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map';

import {AuthService} from './auth-service';
import {SitesService} from './sites-service';
import {BanchesService} from './banches-service';
import {DevicesService} from './devices-service';
import {ReadingsService} from './readings-service';
import {CommonService} from './common-service';

/*
  Generated class for the DbService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class DbService {

	
  constructor(public http: Http, public storage: Storage, public sitesService: SitesService,
    public commonService: CommonService, public banchesService: BanchesService,
    public readingsService: ReadingsService, public authService: AuthService,
    public devicesService: DevicesService) {
  }

  public setSites(sites: any){
    this.sitesService.setSites(sites);
  }

  public getSites(token: any){
  	return this.sitesService.getSites(token);
  }

  public getSiteById(token: any, siteId: any){
    return this.sitesService.getSiteById(token, siteId);
  }

  public setBanches(banches: any){
    this.banchesService.setbanches(banches);
  }

  public getBanches(token: any, siteId: any){
    return this.banchesService.getBanches(token, siteId);
  }

  public setReading(bancheId, serialNumber, dataArr){
    this.readingsService.setReading(bancheId, serialNumber, dataArr);
  }

  public login(credentials){
    return this.authService.login(credentials);
  }

  public getUserRemember(){
    return this.authService.getUserRemember();
  }

  public getUserInfo(){
    return this.authService.getUserInfo();
  }

  public setDevices(devices: any){
    this.devicesService.setDevices(devices);
  }

  public getDevices(token, bancheId){
    return this.devicesService.getDevices(token, bancheId);
  }
}
