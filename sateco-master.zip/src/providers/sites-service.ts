import { Injectable } from '@angular/core';
import { Headers, Http, Request, RequestOptions, RequestMethod } from '@angular/http';
import {Observable} from 'rxjs/Observable';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map';

import {CommonService} from './common-service';

//SITE MODEL
export class Site {
	id: number;
	name: string;
	address: string;
	lat: number;
	lng: number;
	created: string;

	constructor(id: number, name: string, address: string, lat: number, lng: number, created: string) {
		this.id = id;
		this.name = name;
		this.address = address;
		this.lat = lat;
		this.lng = lng;
		this.created = created;
	}
}


/*
  Generated class for the SitesService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
  	*/
  @Injectable()
  export class SitesService {
  	dbSites: Storage;
  	currentSite: Site;
  	currentSites: Array<Site> = [];

  	constructor(public http: Http, storage: Storage, public commonService: CommonService) {
  		this.dbSites = new Storage({
  			name: this.commonService.sites_dbName,
  			driverOrder: this.commonService.driverOrder
  		});

  		this.dbSites.ready().then(() => {
  			// Or to get a key/value pair
  			this.dbSites.get(this.commonService.sites_dbName).then( data => {
  				if (data == null){
  					this.currentSites = [];
          }
          else{
            this.currentSites = JSON.parse(data);
          }
        }).catch((error: any) => {
          this.dbSites.set(this.commonService.sites_dbName, '[]');
          this.currentSites = [];
        });
      });
  	}

  	setSites(site: Array<Site>){
  		this.dbSites.set(this.commonService.sites_dbName, JSON.stringify(site));
  	}

    public getSiteById(token: any, siteId: any){
      if (this.commonService.checkNetwork()){
        var headers = new Headers();
        headers.append('Authorization', token);
        var link = this.commonService.host + this.commonService.site_api + "/" + siteId;
        let options = new RequestOptions({
          method: RequestMethod.Get,
          url: link,
          headers: headers
        });
        return Observable.create(observer => {
          // At this point make a request to your backend to make a real check!
          this.http.get(link, options).map(res => res.json())
          .subscribe(data => {

            this.currentSite = new Site(data.site.id, data.site.name, 
              data.site.address, data.site.lat, data.site.lng, data.site.created);

            observer.next(this.currentSite);
            observer.complete();
          });
        });
      }else{
        return Observable.create(observer => {
          for (var _siteIndex in this.currentSites) {
            if (this.currentSites[_siteIndex].id == siteId){
              this.currentSite = this.currentSites[_siteIndex];
              //Check username password offline
              observer.next(this.currentSite);
              observer.complete();
            }
          }
        });
      }
      
    }

    public getSites(token: any) {
      var headers = new Headers();
      headers.append('Authorization', token);
      var link = this.commonService.host + this.commonService.sites_api;
      let options = new RequestOptions({
        method: RequestMethod.Get,
        url: link,
        headers: headers
      });
      if (this.commonService.checkNetwork()) {
        return Observable.create(observer => {
          // At this point make a request to your backend to make a real check!
          this.http.get(link, options).map(res => res.json()).subscribe(data => {
            //Loop data respone 
            for (let _siteIndex in data.sites){
              //Create new site
              let siteItem = data.sites[_siteIndex];

              this.currentSite = new Site(siteItem.id, siteItem.name, 
                siteItem.address, siteItem.lat, siteItem.lng, siteItem.created);

              let isExist = false;

              //Loop current site on database 
              if(this.currentSites.length < 1) {
                this.currentSites.push(this.currentSite);
              }
              else{
                for (var sitesIndex in this.currentSites) {
                  if( this.currentSites[sitesIndex].id == this.currentSite.id){
                    this.currentSites[sitesIndex] = this.currentSite;
                    isExist = true;
                    break;
                  }else{
                    isExist = false;
                  }
                }
                if( !isExist ){
                  this.currentSites.push(this.currentSite);
                }
              }
            }
            this.setSites(this.currentSites);

            observer.next(this.currentSites);
            observer.complete();
          });
        });
      }else{
        return Observable.create(observer => {
          observer.next(this.currentSites);
          observer.complete();
        });
      }
    }
  }
