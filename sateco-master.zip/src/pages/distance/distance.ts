import { Component, ViewChild, Directive, ElementRef } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { Http } from '@angular/http';
import { Chart } from 'chart.js';
import { ChartsModule } from 'ng2-charts';
import { AuthService } from '../../providers/auth-service';
import { DataService } from '../../providers/data-service';
import { ChartService } from '../../providers/chart-service';
/**
 * Generated class for the Register page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
 @Component({
     selector: 'page-distance',
     templateUrl: 'distance.html',
 })
 export class DistancePage {

     @ViewChild('height') heightElement: ElementRef;
     
     heightChart;

     constructor(public chartservice: ChartService, public params: NavParams, public http: Http, 
         public nav: NavController, private auth: AuthService, public storage: Storage) {
         var banche_id = 1;
        
         // this.chartservice.getDataTimeNow(this.auth.getUserInfo().token, banche_id, this.heightChart, "height");
     }

     ionViewDidLoad() {
         this.initHeightChart();
     }

     initHeightChart() {
         let chartType = 'line';

         let data = {
             datasets: [
             {
                 label: "Height",
                 fill: false,
                 lineTension: 0.1,
                 backgroundColor: "rgba(75,192,192,0.4)",
                 borderColor: "rgba(75,192,192,1)",
                 borderCapStyle: 'butt',
                 borderDash: [],
                 borderDashOffset: 0.0,
                 borderJoinStyle: 'miter',
                 pointBorderColor: "rgba(75,192,192,1)",
                 pointBackgroundColor: "#fff",
                 pointBorderWidth: 1,
                 pointHoverRadius: 5,
                 pointHoverBackgroundColor: "rgba(75,192,192,1)",
                 pointHoverBorderColor: "rgba(220,220,220,1)",
                 pointHoverBorderWidth: 2,
                 pointRadius: 1,
                 pointHitRadius: 10,
                 spanGaps: false,
             }
             ]
         };

         let options = {
             scales: {
                 yAxes: [{
                     ticks: {
                         beginAtZero: true
                     }
                 }],
                 xAxes: [{
                     ticks: {
                         autoSkip: true,
                         maxTicksLimit: 5
                     }
                 }]
             },
             legend: {
                 display: false
             },
             responsive: false
         };

         this.heightChart = this.chartservice.createChart(
             this.heightElement.nativeElement.getContext('2d'), chartType, data, options);
     }
 }
