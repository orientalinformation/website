import { Component, NgModule } from '@angular/core';
import { ModalController, IonicPage, NavController, NavParams } from 'ionic-angular';

import { AboutPage } from '../about/about';
import { ContactPage } from '../contact/contact';

import { CalibzeroPage } from '../calibzero-page/calibzero-page';
import { CalibpointPage } from '../calibpoint-page/calibpoint-page';
import { TolerancePage } from '../tolerance-page/tolerance-page';
import { ValeurMaxPage } from '../valeur-max-page/valeur-max-page';

import { SerialService } from '../../providers/serial-service';
import { CommonService } from '../../providers/common-service';
import { DbService } from '../../providers/db-service';


/**
 * Generated class for the SettingsPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

 declare function escape(s:string): string;
 declare function unescape(s:string): string;

 @Component({
   selector: 'page-settings-page',
   templateUrl: 'settings-page.html',
 })

 export class SettingsPage {
   // lblDeviceId: any;

   pressionSerialNumber: string;
   inclinometerSerialNumber: string;
   rangingSerialNumber: string;

   pressionPage: HTMLElement;
   inclinometerPage: HTMLElement;
   distancePage: HTMLElement;
   openPress: HTMLElement;
   openInclinometer: HTMLElement;
   openDistance: HTMLElement;
   lblWeight: HTMLElement;

   bancheId: string;

   constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController,
     public serialService: SerialService, public commonService: CommonService, public dbService: DbService) {
     this.bancheId = this.navParams.get("bancheId");
     console.log(this.navParams);
     this.dbService.getDevices(this.dbService.getUserInfo().token, this.navParams.get("bancheId")).subscribe(
       devices => {
         for (var _deveiceIndex in devices) {
           let deviceItem = devices[_deveiceIndex];
           if ( deviceItem.bancheId == this.bancheId ){
             let devicePart = deviceItem.serialNumber.substr(2,1);
             if (devicePart == "P")
               this.pressionSerialNumber = deviceItem.serialNumber;
             if ( deviceItem == "I" )
               this.inclinometerSerialNumber = deviceItem.serialNumber;
             if ( deviceItem == "R" )
               this.rangingSerialNumber = deviceItem.serialNumber;
           }
         }
       }, error => {
       });
   }

   ionViewDidLoad() 
   {
     this.pressionPage = <HTMLElement>document.querySelector("#pressionPage");
     this.inclinometerPage = <HTMLElement>document.querySelector("#inclinometerPage");
     this.distancePage = <HTMLElement>document.querySelector("#distancePage");

     this.openPress = <HTMLElement>document.querySelector("#openPress");
     this.openInclinometer = <HTMLElement>document.querySelector("#openInclinometer");
     this.openDistance = <HTMLElement>document.querySelector("#openDistance");

     this.lblWeight = <HTMLElement>document.querySelector("#lblWeight");
     this.showPressionPage();
     this.readDataSerial();
   }

   showPressionPage()
   {
     this.pressionPage.style.display = "flex";
     this.inclinometerPage.style.display = "none";
     this.distancePage.style.display = "none";
     this.openPress.style.backgroundColor = "skyblue";
     this.openInclinometer.style.backgroundColor = "white";
     this.openDistance.style.backgroundColor = "white";
   }

   showIncinometerPage()
   {
     this.pressionPage.style.display = "none";
     this.inclinometerPage.style.display = "flex";
     this.distancePage.style.display = "none";
     this.openInclinometer.style.backgroundColor = "skyblue";
     this.openPress.style.backgroundColor = "white";
     this.openDistance.style.backgroundColor = "white";
   }

   showDistancePage()
   {
     this.pressionPage.style.display = "none";
     this.inclinometerPage.style.display = "none";
     this.distancePage.style.display = "flex";
     this.openDistance.style.backgroundColor = "skyblue";
     this.openPress.style.backgroundColor = "white";
     this.openInclinometer.style.backgroundColor = "white";
   }

   openModal(page: any, deviceId: any, fncName: any){
     let modal = this.modalCtrl.create(page, {
       deviceId: deviceId,
       functionName: fncName
     });
     modal.present();
     modal.onDidDismiss(data => {
       this.readDataSerial();
     });
   }

   openCalibZero() 
   {
     this.openModal(CalibzeroPage, this.pressionSerialNumber, this.commonService.fncCalibZero);
   }

   openCalibPoint()
   {
     this.openModal(CalibpointPage, this.pressionSerialNumber, this.commonService.fncCalibPoint);
   }

   openTolerance()
   {
     this.openModal(TolerancePage, this.pressionSerialNumber, this.commonService.fncSetTol);
   }

   openValueMax()
   {
     this.openModal(ValeurMaxPage, this.pressionSerialNumber, this.commonService.fncSetMax);
   }

   readDataSerial(){
     this.serialService.readyRead().subscribe(
       (data) => {//success callback
         let result = "";
         let view = new Uint8Array(data);
         for(var i in view){
           if(view[i] == 13 || view[i] == 10){
             this.showData(result)
           }else{
             result += unescape(escape(String.fromCharCode(view[i])));
           }
         }
       },
       () => {//error callback

       },
       () => {}//complete callback
       );
   }

   showData(dtRespone: string){
     let dtResult = [];
     dtResult = dtRespone.replace(/\r?\n/g, "").split(" ");
     let dvId: string, value: string;
     dvId = dtResult[0];
     value = dtResult[1];
     if ( this.pressionSerialNumber == dvId)
       this.lblWeight.innerHTML = value;
   }

 }