import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { PressurePage } from '../../pages/pressure/pressure';
import { DistancePage } from '../../pages/distance/distance';
import { Http } from '@angular/http';


@Component({
	selector: 'page-tabs',
	templateUrl: 'tabs.html'
})
export class TabsPage {

	public tbPression = PressurePage;
	public tbInclinometer = DistancePage;
	constructor(public params: NavParams) {
		
	}


}
