import { Component, ViewChild, Directive, ElementRef } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { Http } from '@angular/http';
import { Chart } from 'chart.js';
import { ChartsModule } from 'ng2-charts';
import { AuthService } from '../../providers/auth-service';
import { ChartService } from '../../providers/chart-service';
import { DbService } from '../../providers/db-service';

import { CommonService } from '../../providers/common-service';


/**
 * Generated class for the Register page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
 @Component({
     selector: 'page-pressure',
     templateUrl: 'pressure.html',
 })
 export class PressurePage {

     @ViewChild('pressure') pressureElement: ElementRef;
     pressureChart;
     
     constructor(public chartService: ChartService, public params: NavParams, public http: Http,
         public nav: NavController, private auth: AuthService, public dbService: DbService,
         public commonService: CommonService) {

     }

     ionViewDidLoad() {
         // this.chartService.getDataTimeNow(this.auth.getUserInfo().token, banche_id, this.pressureChart, "pressure");
         //  var that = this;
         this.initPressureChart();

         var that = this;
         setInterval(function() {
             if (typeof that.pressureChart != "undefined"){
                 if ( typeof that.commonService.pressionVal != "undefined" && that.commonService.isResponse) {
                     if (that.pressureChart.data.labels.length >= 50) {
                         that.pressureChart.data.labels.shift();
                         that.pressureChart.data.datasets[0].data.shift();
                     }
                     that.pressureChart.update();
                     
                     that.pressureChart.data.datasets[0].data.push(that.commonService.pressionVal);
                     that.pressureChart.data.labels.push(that.commonService.created);
                     that.pressureChart.update();
                     that.commonService.isResponse = false;
                 }
             }
         },2000);
     }

     initPressureChart() {
         let chartType = 'line';

         let data = {
             datasets: [
             {
                 label: "Pression",
                 fill: false,
                 lineTension: 0.1,
                 backgroundColor: "rgba(75,192,192,0.4)",
                 borderColor: "rgba(75,192,192,1)",
                 borderCapStyle: 'butt',
                 borderDash: [],
                 borderDashOffset: 0.0,
                 borderJoinStyle: 'miter',
                 pointBorderColor: "rgba(75,192,192,1)",
                 pointBackgroundColor: "#fff",
                 pointBorderWidth: 1,
                 pointHoverRadius: 5,
                 pointHoverBackgroundColor: "rgba(75,192,192,1)",
                 pointHoverBorderColor: "rgba(220,220,220,1)",
                 pointHoverBorderWidth: 2,
                 pointRadius: 1,
                 pointHitRadius: 10,
                 spanGaps: false,
             }
             ]
         };

         let options = {
             scales: {
                 yAxes: [{
                     ticks: {
                         beginAtZero: true
                     }
                 }],
                 xAxes: [{
                     ticks: {
                         autoSkip: true,
                         maxTicksLimit: 5
                     }
                 }]
             },
             legend: {
                 display: false
             },
             responsive: false
         };

         this.pressureChart = this.chartService.createChart(this.pressureElement.nativeElement.getContext('2d'), 
             chartType, data, options);
     }
 }
