import { Component, ViewChild, ElementRef } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { SettingsPage } from '../../pages/settings-page/settings-page';
import { DistancePage } from '../../pages/distance/distance';
import { PressurePage } from '../../pages/pressure/pressure';
import { TabsPage } from '../../pages/tabs/tabs';

import { AuthService } from '../../providers/auth-service';
import { DbService } from '../../providers/db-service'
import { SitesService } from '../../providers/sites-service'
import { SerialService } from '../../providers/serial-service'
import { CommonService } from '../../providers/common-service'
import { ChartService } from '../../providers/chart-service'

/**
 * Generated class for the SitePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
 @Component({
   selector: 'page-site-page',
   templateUrl: 'site-page.html',
 })
 export class SitePage {
   currentBanches: Array<any> = [];
   idActive: number;

   viewSiteInfo: HTMLElement;
   siteInfo: HTMLElement;
   iconSetting: HTMLElement;

   // tabChart: HTMLElement;

   siteId: number;
   siteName: string;
   siteAddress: string; 
   siteCreated: string;

   // this tells the tabs component which Pages
   // should be each tab's root Page
   // tbPression = PressurePage;
   // tbHeight = DistancePage;

   bancheId;

   constructor(public navCtrl: NavController, public navParams: NavParams, public dbService: DbService,
     public authService: AuthService, public siteService: SitesService, public serialService: SerialService,
     public commonService: CommonService, public chartService: ChartService) {
     this.siteId = this.navParams.get("site_id");
     // this.siteId = 1;
     let token = this.authService.getUserInfo().token;
     this.siteService.getSiteById(token, this.siteId).subscribe(data => {
       this.siteName = data.name;
       this.siteAddress = data.address;
       this.siteCreated = data.created;
     });

     this.dbService.getBanches(token, this.siteId).subscribe(data => {
       this.currentBanches = data;
     });
   }

   ionViewDidLoad() {
     this.viewSiteInfo = <HTMLElement>document.getElementById("viewSiteInfo");
     this.viewSiteInfo.style.backgroundColor = "skyblue";

     this.siteInfo = <HTMLElement>document.getElementById("siteInfo");
     this.siteInfo.style.display = "flex";

     this.iconSetting = <HTMLElement>document.getElementById("iconSetting");
     this.iconSetting.style.display = "none";

     // this.tabChart = <HTMLElement>document.getElementById("tabChart");
     // this.tabChart.style.display = "none";
   }

   goSettings(){
     this.navCtrl.push(SettingsPage, {
       bancheId: this.bancheId
     });
   }

   viewBancheDetail(bancheId){
     if (bancheId >= 0 ){
       for (let bancheIndex in this.currentBanches) {
         let bancheItem = <HTMLElement>document.getElementById("banche" + this.currentBanches[bancheIndex].id);
         let showBancheItem = <HTMLElement>document.getElementById("showBanche" + this.currentBanches[bancheIndex].id);
         let presssionVal = <HTMLElement>document.getElementById("presssionVal" + this.currentBanches[bancheIndex].id);
         // let thickNessVal = <HTMLElement>document.getElementById("thickNessVal" + this.currentBanches[bancheIndex].id);
         // let heightVal = <HTMLElement>document.getElementById("heightVal" + this.currentBanches[bancheIndex].id);
         // let rollVal = <HTMLElement>document.getElementById("rollVal" + this.currentBanches[bancheIndex].id);
         // let pitchVal = <HTMLElement>document.getElementById("pitchVal" + this.currentBanches[bancheIndex].id);
         presssionVal.innerHTML = this.commonService.err_notConnect;
         // thickNessVal.innerHTML = this.commonService.err_notConnect;
         // heightVal.innerHTML = this.commonService.err_notConnect;
         // rollVal.innerHTML = this.commonService.err_notConnect;
         // pitchVal.innerHTML = this.commonService.err_notConnect;

         if (this.currentBanches[bancheIndex].id == bancheId) {
           bancheItem.style.display = "flex";
           showBancheItem.style.backgroundColor = "skyblue";
           // this.serialService.readSerialByBancheId(bancheId, presssionVal, thickNessVal,
             // heightVal, rollVal, pitchVal);
           this.serialService.readSerialByBancheId(bancheId, presssionVal);
           this.bancheId = bancheId;
           // this.tabChart.style.display = "flex";
         }else{
           bancheItem.style.display = "none";
           showBancheItem.style.backgroundColor = "white";
         }
       }
       this.viewSiteInfo.style.backgroundColor = "white";
       this.siteInfo.style.display = "none";
       if ( this.authService.getUserInfo().roleId == 1)
       this.iconSetting.style.display = "flex";
     }else{
       this.viewSiteInfo.style.backgroundColor = "skyblue";
       this.siteInfo.style.display = "flex";
       this.iconSetting.style.display = "none";
       // this.tabChart.style.display = "none";
       for (let bancheIndex in this.currentBanches) {
         let bancheItem = <HTMLElement>document.getElementById("banche" + this.currentBanches[bancheIndex].id);
         let showBancheItem = <HTMLElement>document.getElementById("showBanche" + this.currentBanches[bancheIndex].id);
         bancheItem.style.display = "none";
         showBancheItem.style.backgroundColor = "white";
       }
     }
   }

 }
