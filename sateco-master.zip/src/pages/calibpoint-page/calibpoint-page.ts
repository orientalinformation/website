import { Component } from '@angular/core';
import { ViewController, IonicPage, NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import { SerialService } from '../../providers/serial-service';
/**
 * Generated class for the CalibpointPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

 declare function escape(s:string): string;
 declare function unescape(s:string): string;

 @Component({
   selector: 'page-calibpoint-page',
   templateUrl: 'calibpoint-page.html',
 })
 export class CalibpointPage {
   private deviceId: string;
   private calibValue: string;
   private functionName: string;
   public valProgress: number;
   public btnDisabled: boolean;

   constructor(public navCtrl: NavController, public navParams: NavParams,public viewCtrl: ViewController,
     public loading: LoadingController, public serialService: SerialService,
     private toastCtrl: ToastController) {
     this.deviceId = navParams.get("deviceId");
     this.functionName = navParams.get("functionName");
     this.valProgress = 0;
     this.btnDisabled = true;
   }

   ionViewDidLoad() {
   }

   closeModal() {
     this.viewCtrl.dismiss();
   }

   keypressVal(){
     if (this.calibValue == "" || typeof this.calibValue == "undefined"){
       this.btnDisabled = true;
     }else{
       this.btnDisabled = false;
     }
   }

   calibPoint() {
     if (this.calibValue == "" || typeof this.calibValue == "undefined"){
       let toast = this.toastCtrl.create({
         message: 'Please input calibrate point valeur',
         duration: 3000,
         position: 'middle'
       });

       toast.onDidDismiss(() => {
       });

       toast.present();
     }else{
       let intervalId = setInterval(() => {  
         this.valProgress += 1;
         if(this.valProgress == 100)
           this.valProgress = 0;
       }, 100);
       // let loader = this.loading.create({
         //   content: 'Calibrating ...',
         // });

         // loader.present().then(() => {
           this.btnDisabled = true;
           this.serialService.write(this.deviceId + " " + this.functionName + " " + this.calibValue + "\n");
           this.serialService.readyRead().subscribe(
             (data) => {//success callback
               let result = "";
               let view = new Uint8Array(data);
               for(var i in view){
                 if(view[i] == 13 || view[i] == 10){
                   if(this.isComplete(result)){
                     clearInterval(intervalId);
                     this.valProgress = 100;
                     let toast = this.toastCtrl.create({
                       message: 'Calibrate point complete',
                       duration: 3000,
                       position: 'middle'
                     });
                     toast.present();
                     this.btnDisabled = false;
                     this.closeModal();
                   }
                 }else{
                   result += unescape(escape(String.fromCharCode(view[i])));
                 }
               }
             },
             () => {//error callback

             },
             () => {}//complete callback
             );
           // });
         }
       }

       isComplete(dtRespone: string): boolean{
         let dtResult = [];
         dtResult = dtRespone.replace(/\r?\n/g, "").split(" ");
         let dvId: string, key: string, value: string;
         dvId = dtResult[0];
         key = dtResult[1];
         if ( this.deviceId == dvId && key == this.functionName ) {
           return true;
         }
         return false;
       }
     }
