import { Component } from '@angular/core';
import { IonicPage, NavController, AlertController, LoadingController, Loading } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { HomePage } from '../../pages/home/home';
import { SettingsPage } from '../../pages/settings-page/settings-page';
import { SitePage } from '../../pages/site-page/site-page';
import { DbService } from '../../providers/db-service';
import { SerialService } from '../../providers/serial-service';
import { CommonService } from '../../providers/common-service';
/**
 * Generated class for the LoginPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
 @Component({
   selector: 'page-login-page',
   templateUrl: 'login-page.html',
 })
 export class LoginPage {

   loading: Loading;
   registerCredentials = {username: '', password: '', remember: 0};

   constructor(private nav: NavController, private dbService: DbService, private alertCtrl: AlertController, 
     private loadingCtrl: LoadingController, storage: Storage, public serialService: SerialService,
     private commonService: CommonService) {
   }

   ionViewDidLoad() {
     this.dbService.getUserRemember().subscribe(dataRemember => {
       try{
         this.registerCredentials.username = dataRemember.username;
         this.registerCredentials.password = dataRemember.password;
         if (this.registerCredentials.username != "")
           this.registerCredentials.remember = 1;
       }catch(ex){
         console.log(ex);
       }
     });
   }

   public login() {
     this.showLoading()
     this.dbService.login(this.registerCredentials).subscribe(dataLogin => {
       if (dataLogin[0]) {
         setTimeout(() => {
           this.serialService.getAllDatabase(dataLogin[1]);
           this.loading.dismiss();
           this.nav.setRoot(HomePage);
           // this.nav.setRoot(SettingsPage);
           // this.nav.setRoot(SitePage).then(data => {
         });
       } else {
         this.showError(this.commonService.err_login);
       }
     },
     error => {
       this.showError(this.commonService.err_login);
     });
   }

   showLoading() {
     this.loading = this.loadingCtrl.create({
       content: 'Please wait...'
     });
     this.loading.present();
   }

   showError(text) {
     setTimeout(() => {
       this.loading.dismiss();
     });

     let alert = this.alertCtrl.create({
       title: 'Échouer',
       subTitle: text,
       buttons: ['OK']
     });
     alert.present(prompt);
   }


 }