jQuery(document).ready(function () {
	$('.container').carousel({
        num: 5,
        maxWidth: 600,
        maxHeight: 400,
        distance: 50,
        scale: 0.6,
        // animationTime: 1000,
        // showTime: 4000,
        autoPlay: false
    });
    $("#container").mousewheel(function(event, delta) {
    	if(delta > 0) {
	        $(" img.prev", this).click();
    	}
    	if (delta < 0) {
    		$(" img.next", this).click();
    	}
        // this.scrollLeft -= (delta * 30);
        event.preventDefault();

    });
});