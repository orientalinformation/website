$(document).ready(function(){
	$('.works').mixItUp();
});