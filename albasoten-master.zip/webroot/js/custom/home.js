function onrender_home() {
	var slider = $("#slider").slippry();

  $('.stop').click(function () {
    slider.stopAuto();
  });

  $('.start').click(function () {
    slider.startAuto();
  });

  $('.prev').click(function () {
    slider.goToPrevSlide();
    return false;
  });
  $('.next').click(function () {
    slider.goToNextSlide();
    return false;
  });
  $('.reset').click(function () {
    slider.destroySlider();
    return false;
  });
  $('.reload').click(function () {
    slider.reloadSlider();
    return false;
  });
  $('.init').click(function () {
    slider = $(".slider").slippry();
    return false;
  });
  $(".controls li a").click(function (e) {
    e.preventDefault();
  });
};
