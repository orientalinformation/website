<?php
/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link      http://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\ORM\TableRegistry;
use Cake\ORM\Entity;
use Cake\Event\Event;
use Cake\Filesystem\Folder;
use Cake\Filesystem\File;
use Cake\View\View;

/**
 * Static content controller
 *
 * This controller will render views from Template/Pages/
 *
 * @link http://book.cakephp.org/3.0/en/controllers/pages-controller.html
 */

class AdminController extends AppController
{
    public $session;

    public function beforeFilter()
    {
        parent::beforeFilter();
        $this->layout = 'admin';

        $this->session = $this->request->session();
    }

    public function checklogin()
    {
        if (empty($this->request->session()->read('check.login'))) {
            $this->redirect(array('action' => 'login'));
        }
    }

    
    public function login()
    {
        $this->layout=false;

        if ($this->request->is('post')) {
            $Username=$this->request->data('Username');
            $Password=$this->request->data('Password');
            if ('albasoten' == $Username && 'adminalbasoten' == $Password){
                $this->request->session()->write('check.login', "true");
                $this->redirect(array('action' => 'index'));
            }
            if ('albasoten' != $Username || 'adminalbasoten' != $Password){
                setcookie("error","Username or password incorrect", time() +5);
                $this->redirect(array('action' => 'login'));
            }
        }        
    }

    public function logout()
    {
        $this->request->session()->delete('check.login');
        $this->redirect(['controller' => 'Admin', 'action' => 'login']);
    }

    public function index()
    {
        $this->checklogin();
        $slidesTable   = TableRegistry::get('Slides');
        $imagesTable   = TableRegistry::get('Images');
        $pagesTable   = TableRegistry::get('Pages');
        $pages  = $pagesTable->findByLocation('home')->first();

        if ($this->request->is('post')) {
            $data = $this->request->data;
            if ($_FILES["file"]["error"] != 4) {
                // $slidesEntity = $slidesTable->newEntity();
                $imagesEntity = $imagesTable->newEntity();
                $tmp_name = $_FILES["file"]["tmp_name"];
                $name = $_FILES["file"]["name"];
                // $slidesEntity->name = $name;
                $imagesEntity->name = $name;
                $imagesEntity->page_id = 1;
                $image = $imagesTable->save($imagesEntity);
                // $slide = $slidesTable->save($slidesEntity);
                // $slideId = $slide->id;
                $dir = WWW_ROOT.'upload/'.$image->id.'-'.$name;
                move_uploaded_file($tmp_name, $dir);
            }

            $pagesEntity = $pagesTable->get($pages->id);
            $pagesEntity->title = $data['titleBottom'];
            $pagesEntity->content = $data['contentBottom'];
            $pagesTable->save($pagesEntity);

            return $this->redirect('/admin');
        }

        $images = $imagesTable->findByPageId('1');
        foreach ($images as $key => $value) {
            $value->name = '/upload/'.$value->id.'-'.$value->name;
        }

        $this->set('slides', $images);
        $this->set('pagesTitle', $pages->title);
        $this->set('pagesContent', $pages->content);

    }

    public function addSlide()
    {
        $this->checklogin();
    }

    public function quiSommesNous()
    {
        $this->checklogin();
        $pagesTable   = TableRegistry::get('Pages');
        $pages  = $pagesTable->findByLocation('qui-sommes-nous')->first();
        $this->set('pagesTitle', $pages->title);
        $this->set('pagesContent', $pages->content);
    }

    public function addQuiSommesNous()
    {
        $this->checklogin();
        $pagesTable   = TableRegistry::get('Pages');
        $pages  = $pagesTable->findByLocation('qui-sommes-nous')->first();
        if ($this->request->is('post')) {
            $data = $this->request->data;
            $pagesEntity = $pagesTable->get($pages->id);
            $pagesEntity->title = $data['title'];
            $pagesEntity->content = $data['content'];
            $pagesTable->save($pagesEntity);

            return $this->redirect('/admin/qui-sommes-nous');
        }
        $this->set('pagesTitle', $pages->title);
        $this->set('pagesContent', $pages->content);
    }

    public function historique()
    {
       $this->checklogin();
       $pagesTable   = TableRegistry::get('Pages');
       $pages = $pagesTable->find('all')->where(['location' => 'historique']);
       $this->set('pages', $pages);
    }

    public function addHistorique($id = null)
    {
        $this->checklogin();
        $pagesTable     = TableRegistry::get('Pages');
        $imagesTable    = TableRegistry::get('Images');

        $page = $pagesTable->findById($id)->first();
        $images = $imagesTable->findByPageId($page->id)->order(['position' => 'ASC']);
        $pagesContent = explode("!^0^!", $page->content);
        $this->set('images', $images);
        $this->set('page', $page);
        $this->set('pagesContent', $pagesContent);
        if (isset($id) && !empty($id)) {
            $this->set('checkItem',true);
        } else {
            $this->set('checkItem',false);
        }
        if ($this->request->is('post')) {
            $data = $this->request->data;
            if(empty($data['pageId'])) {
                $pagesEntity = $pagesTable->newEntity();
            } else {
                $pagesEntity = $pagesTable->get($data['pageId']);
            }
            $pagesEntity->title = $data['title'];
            $content = "";
            foreach ($data['listItem'] as $key => $value) {
                if (!empty($value)) {
                        $content .= $value ."!^0^!";
                }
            }            
            $pagesEntity->content   = $content;
            $pagesEntity->period    = $data['period'];
            $pagesEntity->location  = "historique";
            $pagesTb = $pagesTable->save($pagesEntity);

            foreach ($_FILES["files"]["error"] as $key => $value) {
                if ($value != 4) {
                    $imagesEntity = $imagesTable->newEntity();
                    $tmp_name = $_FILES["files"]["tmp_name"][$key];
                    $name = $_FILES["files"]["name"][$key];
                    $imagesEntity->name = $name;
                    $imagesEntity->page_id = $pagesTb->id;
                    $images = $imagesTable->save($imagesEntity);
                    $dir = WWW_ROOT.'upload/image-'.$images->id.'-'.$name;
                    move_uploaded_file($tmp_name, $dir);
                }
            }
            foreach ($data['quantity'] as $key => $value) {
                $imagesEntity = $imagesTable->get($key);
                $imagesEntity->percent = $value;
                $imagesTable->save($imagesEntity);
            }
            foreach ($data['position'] as $key => $value) {
                $imagesEntity = $imagesTable->get($key);
                $imagesEntity->position = $value;
                $imagesTable->save($imagesEntity);
            }
            return $this->redirect('/admin/historique');
        }
    }

    public function nosConcerts()
    {
        $this->checklogin();
        $pagesTable   = TableRegistry::get('Pages');
        $pages = $pagesTable->find('all')->where(['location' => 'nos-concerts']);
        $this->set('pages', $pages);
    }

    public function addNosConcerts($id = null)
    {
        $this->checklogin();
        $pagesTable   = TableRegistry::get('Pages');
        $imagesTable   = TableRegistry::get('Images');
        $page = $pagesTable->findById($id)->first();
        $image = $imagesTable->findByPageId($id)->first();
        $this->set('image', $image);
        $this->set('page', $page);
        if ($this->request->is('post')) {
            $data = $this->request->data;
            if(empty($id)) {
                $pagesEntity = $pagesTable->newEntity();
            } else {
                $pagesEntity = $pagesTable->get($id);
            }
            $pagesEntity->title = $data['title'];
            $pagesEntity->content = $data['content'];
            $pagesEntity->location = "nos-concerts";
            $pages = $pagesTable->save($pagesEntity);
            if ($_FILES['file']['error'] != 4) {
                $tmp_name = $_FILES["file"]["tmp_name"];
                $name = $_FILES["file"]["name"];
                $pagesEn = $pagesTable->get($pages->id);

                $pagesEn->icon = $name;
                $pagesTable->save($pagesEn);
                $dir = WWW_ROOT.'upload/nos-'.$pages->id.'-'.$name;
                move_uploaded_file($tmp_name, $dir);
            }
            return $this->redirect('/admin/nosConcerts');

        }
    }

    public function nousContacter()
    {
        $this->checklogin();
    }

    public function deletePage($id)
    {
        $this->checklogin();
        $pagesTable = TableRegistry::get('Pages');
        $imagesTable = TableRegistry::get('Images');
        $images = $imagesTable->findByPageId($id);
        foreach ($images as $key => $value) {
            $imagesEntity = $imagesTable->get($value->id);
            $imagesTable->delete($imagesEntity);
        }
        $pagesEntity = $pagesTable->get($id);
        $pagesTable->delete($pagesEntity);
        return $this->redirect('/admin');
    }

    public function news()
    {
       $this->checklogin();
       $newsTable   = TableRegistry::get('News');
       $news = $newsTable->find('all');
       $this->set('news', $news);
    }

    public function addNews($id = null)
    {
        $this->checklogin();
        $newsTable   = TableRegistry::get('News');

        $news = $newsTable->findById($id)->first();
        $data=$this->set('newsedit', $news);
        //var_dump($data);die();
        //$this->set('event', $event);

        if ($this->request->is('post')) {
            if(empty($id)) {
                $news = $newsTable->newEntity();
            } else {
                $news = $newsTable->get($id);
            }
            $data = $this->request->data;
            if (empty($data['time'])) {
               setcookie("date","Time is not empty", time() +2);
               return $this->redirect('/admin/addNews');
            }
            if (!empty($data['time'])) {
                $news->time = $data['time'];
                $news->event = $data['event'];
                $newsTable->save($news);
                return $this->redirect('/admin/news');
            }
           
        }
    }

    public function listEmails()
    {
        $this->checklogin();
        $url = 'https://pddimp.yandex.ru/api2/admin/email/list?domain=albasoten.fr';

        $header = array("PddToken: L5C6HCKYQRDETXMD27LGM5SUQUHK6KJWQ5WFU4S6EUOM47QXRJMQ");

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_ENCODING, "gzip");
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)');

        $retValue = curl_exec($ch);
        $response = json_decode(curl_exec($ch));
        $ee       = curl_getinfo($ch);
        // print_r($ee);

        // print_r($retValue);
        $json = json_decode($retValue, true);
        // var_dump($json);die();

        $this->set('listEmail', $json['accounts']);
        // var_dump ($json['accounts']);

        // die();
        
    }

    public function addEmail($name = null)
    {
        $this->checklogin();
        $mailsTable   = TableRegistry::get('Mails');

        $error = '';
        if (!empty($name)) {
            $mails = $mailsTable->get($name);
            $name = explode("@albasoten.fr", $name);
            $this->set('name', $name[0]);
        }
        if ($this->request->is('post')) {
            $mails = $mailsTable->newEntity();
            $data = $this->request->data;
            $params = array();
            if ($data['password'] == $data['repassword']) {
                $params['domain'] = "albasoten.fr";
                $params['password'] = $data['password'];
                if(!empty($data['fname'])) $params['fname'] = $data['fname'];
                if(!empty($data['iname'])) $params['iname'] = $data['iname'];
                if(!empty($data['byear']) && !empty($data['bmonth']) && !empty($data['bday'])) {
                    $params['birth_date'] = $data['byear'].'-'.$data['bmonth'].'-'.$data['bday'];
                }
                if(!empty($data['sex'])) $params['sex'] = $data['sex'];
                if(!empty($data['hintq'])) $params['hintq'] = urlencode($data['hintq']);
                if(!empty($data['hinta'])) $params['hinta'] = urlencode($data['hinta']);
                
                if (empty($name)) {
                    $params['login'] = $data['login']."@albasoten.fr";
                    $url = 'https://pddimp.yandex.ru/api2/admin/email/add';
                } else {
                    $params['login'] = $name[0]."@albasoten.fr";
                    $url = 'https://pddimp.yandex.ru/api2/admin/email/edit';
                }
                $header = array("PddToken: L5C6HCKYQRDETXMD27LGM5SUQUHK6KJWQ5WFU4S6EUOM47QXRJMQ");
                $postData = '';
                foreach($params as $k => $v) 
                { 
                    $postData .= $k . '='.$v.'&'; 
                }
                $postData = rtrim($postData, '&');
                $ch = curl_init();  
                curl_setopt($ch,CURLOPT_URL,$url);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
                curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
                curl_setopt($ch,CURLOPT_HEADER, false); 
                curl_setopt($ch, CURLOPT_POST, count($postData));
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);    
                $output=curl_exec($ch);
                curl_close($ch);


                $mails->username = $params['login'];
                $mails->password = $params['password'];
                $mailsTable->save($mails);

                return $this->redirect('/admin/listEmails');
            } else {
                $this->set('danger','error');
                $this->Flash->error(__("Votre message n'a pas été envoyé!"));
            }
        }
    }

    public function delEmail()
    {
        $this->checklogin();

        $params['domain'] = "albasoten.fr";
        $params['uid'] = $_GET['uid'];
        $url = 'https://pddimp.yandex.ru/api2/admin/email/del';
      
        $header = array("PddToken: L5C6HCKYQRDETXMD27LGM5SUQUHK6KJWQ5WFU4S6EUOM47QXRJMQ");
        $postData = '';
        foreach($params as $k => $v) 
        { 
            $postData .= $k . '='.$v.'&'; 
        }
        $postData = rtrim($postData, '&');
        $ch = curl_init();  
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch,CURLOPT_HEADER, false); 
        curl_setopt($ch, CURLOPT_POST, count($postData));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);    
        $output=curl_exec($ch);
        curl_close($ch);
        $mailsTable   = TableRegistry::get('Mails');
        $mails = $mailsTable->get($_GET['username']);
        $mailsTable->delete($mails);
        $this->redirect('/admin/listEmails');
    }

    public function deleteIcon($id)
    {
        $this->checklogin();
        $pagesTable   = TableRegistry::get('Pages');
        $imagesTable   = TableRegistry::get('Images');
        $entity = $imagesTable->get($id); 
        $pagesId = $entity->page_id;
        $imagesTable->delete($entity);
        return $this->redirect('/admin/addHistorique/'.$pagesId);
    }

    public function deleteSlide($id)
    {
        $this->checklogin();

        $slidesTable   = TableRegistry::get('Slides');
        $entity = $slidesTable->get($id); 
        $slidesTable->delete($entity);
        return $this->redirect('/admin');
    }

    public function deleteNews($id)
    {
        $this->checklogin();
        $newsTable   = TableRegistry::get('News');
        $entity = $newsTable->get($id); 
        $newsTable->delete($entity);
        return $this->redirect('/admin/news');
    }

    public function activate()
    {
        $this->checklogin();
        $mailsTable   = TableRegistry::get('Mails');
        $mails = $mailsTable->get($_GET['username']);
        $this->set('user', $mails->username );
        $this->set('pass', $mails->password );
    }

    public function mailEula() 
    {
        $this->layout = 'blank';
    }

    public function activated()
    {
        $this->layout = 'blank';
    }

}
