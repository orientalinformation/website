<?php
/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link      http://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\ORM\TableRegistry;
use Cake\ORM\Entity;
use Cake\Event\Event;
use Cake\Filesystem\Folder;
use Cake\Filesystem\File;
use Cake\Mailer\Email;
/**
 * Static content controller
 *
 * This controller will render views from Template/Pages/
 *
 * @link http://book.cakephp.org/3.0/en/controllers/pages-controller.html
 */
class PagesController extends AppController
{

    /**
     * Displays a view
     *
     * @return void|\Cake\Network\Response
     * @throws \Cake\Network\Exception\NotFoundException When the view file could not
     *   be found or \Cake\View\Exception\MissingTemplateException in debug mode.
     */

    public $session;

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        
        $this->session = $this->request->session();

        $newsTable   = TableRegistry::get('News');
        $news = $newsTable->find('all')->order(['time' => 'DESC']);
        $this->set('news', $news);
    }

    public function display()
    {
        
        $path = func_get_args();

        $count = count($path);
        if (!$count) {
            return $this->redirect('/');
        }
        $page = $subpage = null;

        if (!empty($path[0])) {
            $page = $path[0];
        }
        if (!empty($path[1])) {
            $subpage = $path[1];
        }
        $this->set(compact('page', 'subpage'));

        try {
            $this->render(implode('/', $path));
        } catch (MissingTemplateException $e) {
            if (Configure::read('debug')) {
                throw $e;
            }
            throw new NotFoundException();
        }
    }

    public function home()
    {
        $this->set('title', 'Home');
        $this->set('scripts', $listScript);
        $this->set('csss', $listCss);

        $slidesTable   = TableRegistry::get('Slides');
        $imagesTable   = TableRegistry::get('Images');
        $pagesTable   = TableRegistry::get('Pages');
        $pages  = $pagesTable->findByLocation('home')->first();
        $slides = $imagesTable->findByPageId('1');
        foreach ($slides as $key => $value) {
            $value->name = 'upload/'.$value->id.'-'.$value->name;
        }
        $this->set('slides', $slides);
        $this->set('pagesTitle', $pages->title);
        $this->set('pagesContent', $pages->content);


    }

    public function aboutus()
    {
        // $this->set('title', 'View Active Users');
    }

    public function quiSommesNous()
    {
        $listScript = array();
        $listCss = array();

        $this->set('title', 'Qui sommes-nous');
        $this->set('scripts', $listScript);
        $this->set('csss', $listCss);
        $pagesTable = TableRegistry::get('Pages');
        $pages      = $pagesTable->findByLocation('qui-sommes-nous')->first();
        $this->set('pagesTitle', $pages->title);
        $this->set('pagesContent', $pages->content);
    }

    public function history()
    {

    }

    public function historique()
    {
        $this->set('title', 'Historique');
        $this->set('scripts', $listScript);
        $this->set('csss', $listCss);

        $pagesTable     = TableRegistry::get('Pages');
        $imagesTable    = TableRegistry::get('Images');

        $page = $pagesTable->find('all', ['contain' => ['Images']])->order(['id' => 'ASC'])->where(['location' => 'historique']);
        // $images = $imagesTable->findByPageId($page->id);
        // $pagesContent = explode("!^0^!", $page->content);
        // $this->set('images', $images);
        $this->set('page', $page);
        // $this->set('pagesContent', $pagesContent);
    }

    public function activities()
    {

    }

    public function nosConcerts()
    {
        $listCss = array();

        $this->set('title', 'Nos concerts');
        $this->set('scripts', $listScript);
        $this->set('csss', $listCss);

        $pagesTable     = TableRegistry::get('Pages');
        $imagesTable    = TableRegistry::get('Images');

        $pages = $pagesTable->find('all')->order(['id' => 'ASC'])->where(['location' => 'nos-concerts']);;
       
        $this->set('pages', $pages);
    }

    public function nousContacter()
    {
        $listScript = array();
        $listCss = array();
        $error = '';
        $success = '';


        if ($this->request->is('post')) {
            $data = $this->request->data;
            // var_dump($data);die();
            // $email = new Email();
            $email = new Email('default');
       
            $email->profile('default');
            $email->to('groupe@albasoten.fr');
            // $email->to('cocungkhongcho@gmail.com');
            $email->subject('Request from '.$this->request->data["fullname"].' <'.$this->request->data["email"].'>');
            $message = '<table>
                            <tr>
                                <td><strong>Full name: </strong></td>
                                <td>'.$this->request->data['fullname'].'</td>
                            </tr>
                            <tr>
                                <td><strong>Email: </strong></td>
                                <td>'.$this->request->data['email'].'</td>
                            </tr>
                            <tr>
                                <td><strong>Phone: </strong></td>
                                <td>'.$this->request->data['phone'].'</td>
                            </tr>
                        </table><hr/><strong>Message: </strong>'.$this->request->data['message'];

            try {
                $email->send($message);
                // success
                $this->session->write('Alert','success');
                $this->Flash->success(__("Votre message a été envoyé!"));
            } catch (SocketException $exception) {
                // failure
                // var_dump($exception);die();
                $this->set('danger','error');
                $this->Flash->error(__("Votre message n'a pas été envoyé!"));
            }
        }

        $this->set('title', 'Nos contacter');
        $this->set('scripts', $listScript);
        $this->set('csss', $listCss);
        // $this->set('error',$error);
        // $this->set('success',$success);
    }

}
