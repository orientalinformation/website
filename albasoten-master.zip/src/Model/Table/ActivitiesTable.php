<?php
namespace App\Model\Table;

use Cake\ORM\Table;

class ActivitiesTable extends Table
{
	public function initialize(array $config)
    {
		$this->hasMany('Projects');
	}
}