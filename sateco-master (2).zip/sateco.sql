-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 15, 2017 at 03:32 PM
-- Server version: 5.5.54-0+deb8u1
-- PHP Version: 5.6.30-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sateco`
--

-- --------------------------------------------------------

--
-- Table structure for table `banches`
--

CREATE TABLE IF NOT EXISTS `banches` (
`id` int(10) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `site_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_active` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banches`
--

INSERT INTO `banches` (`id`, `status`, `site_id`, `created`, `last_active`) VALUES
(1, 1, 1, '2017-04-15 07:26:09', '0000-00-00 00:00:00'),
(2, 1, 2, '2017-04-15 07:26:09', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `address`, `created`) VALUES
(1, 'sateco', 'sateco', '2017-04-15 04:48:30');

-- --------------------------------------------------------

--
-- Table structure for table `readings`
--

CREATE TABLE IF NOT EXISTS `readings` (
`id` int(10) unsigned NOT NULL,
  `pressure` float NOT NULL,
  `thickness` float NOT NULL,
  `height` float NOT NULL,
  `roll` float NOT NULL,
  `pitch` float NOT NULL,
  `banche_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;



--
-- Dumping data for table `readings`
--

INSERT INTO `readings` (`id`, `pressure`, `thickness`, `height`, `roll`, `pitch`, `banche_id`, `created`) VALUES
(1, 1, 2, 3, 4, 5, 1, '2017-04-15 07:38:09'),
(2, 6, 7, 8, 9, 10, 1, '2017-04-15 07:38:27'),
(3, 11, 12, 13, 14, 15, 1, '2017-04-15 07:46:20'),
(4, 17, 18, 19, 20, 21, 1, '2017-04-15 07:38:50'),
(5, 1, 1, 1, 1, 1, 1, '2017-04-15 07:52:30');

-- --------------------------------------------------------

--
-- Table structure for table `sites`
--

CREATE TABLE IF NOT EXISTS `sites` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `lat` double NOT NULL,
  `lng` double NOT NULL,
  `company_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sites`
--

INSERT INTO `sites` (`id`, `name`, `address`, `lat`, `lng`, `company_id`, `created`) VALUES
(1, 'sateco1', 'sateco1', 10, 106, 1, '2017-04-15 06:52:13'),
(2, 'sateco2', 'sateco1', 10, 106, 1, '2017-04-15 06:52:34');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `passsalt` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `role_id` tinyint(4) NOT NULL,
  `company_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `passsalt`, `email`, `role_id`, `company_id`, `created`) VALUES
(1, 'admin', '7d362b1853bbc1d0359063d806af507a7fc3820ab29a0bab67516991b3efd66b39c0e0effadfe647732b06e62f6c01b81a4cd0189e83eef2db981468881c6222', 'ES@4UT3hkW', 'admin@gmail.com', 1, 1, '2017-04-15 05:01:14'),
(2, 'thinhn', '1cd60fe04f24b8d3b5189f2a5ec1d8c66c3689dfcecf69a118a9d71a10b108eebbcfbcc3037d3b561b7c7620335c7c933647a65d6c357ca2f51bb94e3a273f53', '&!72Yh!u(A', 'thinhn@gmail.com', 1, 1, '2017-04-15 06:10:49');

--
-- Indexes for dumped tables
--


CREATE TABLE IF NOT EXISTS `devices` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `serial_number` varchar(50) NOT NULL,
  `banche_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;


ALTER TABLE `devices`
 ADD PRIMARY KEY (`id`);

ALTER TABLE `banches`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `readings`
--
ALTER TABLE `readings`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sites`
--
ALTER TABLE `sites`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banches`
--
ALTER TABLE `banches`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `readings`
--
ALTER TABLE `readings`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `sites`
--
ALTER TABLE `sites`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
