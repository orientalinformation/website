<?php

function dbConnection() 
{
	return new PDO('mysql:dbhost=localhost;dbname=sateco','root','ase45f66');
}

// function insertCompany($data) 
// {
// 	$query = "INSERT INTO companies(name, address, created) VALUES ('".$data['nameCompany']."','".$data['addrCompany']."','".$data['created']."')";
//     $query = mysql_real_escape_string($query);
// 	return dbConnection()->exec($query);
// }

// function updateCompany($data)
// {
// 	$query = "UPDATE companies SET `` = '".$data['nameCompany']."', `` = '".$data['addrCompany']."' WHERE `id` = '".$data['id']."' ";
//     $query = mysql_real_escape_string($query);
// 	return dbConnection()->exec($query);
// }

// function deleteCompany($data)
// {
// 	$query = "DELETE FROM companies WHERE `id` = '".$data['id']."' ";
//     $query = mysql_real_escape_string($query);
// 	return dbConnection()->exec($query);	
// }

function insertUser($data) 
{
    $query = "INSERT INTO users(username, password, passsalt, email, role_id, company_id) VALUES (:username, :password, :passsalt, :email, :role_id, :company_id)";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':username' => $data['username'], 
        ':password' => $data['password'], 
        ':passsalt' => $data['passsalt'], 
        ':email' => $data['email'], 
        ':role_id' => $data['role_id'], 
        ':company_id' => $data['company_id']
    );
    return $sth->execute($data);

}

// function updateUser($data)
// {
// 	$query = "UPDATE users SET `password` = '".$data['password']."', `passsalt` = '".$data['passsalt']."' WHERE `id` = '".$data['id']."'";
//     $query = mysql_real_escape_string($query);
// 	return dbConnection()->exec($query);
// }

// function deleteUser($data)
// {
// 	$query = "DELETE FROM users WHERE `id` = '".$data['id']."' ";
//     $query = mysql_real_escape_string($query);
// 	return dbConnection()->exec($query);
// }

function insertSite($data) 
{
    $query = "INSERT INTO sites(name, address, lat, lng, company_id) VALUES (:name, :address, :lat, :lng, :company_id)";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':name' => $data['name'], 
        ':address' => $data['address'], 
        ':lat' => $data['lat'], 
        ':lng' => $data['lng'], 
        ':company_id' => $data['company_id']
    );
    return $sth->execute($data);
}

// function updateSite($data) 
// {
// 	$query = "UPDATE sites SET `name` = '".$data['nameSite']."', `address` = '".$data['addrSite']."', `type` = '".$data['typeSite']."', `company_id` = '".$data['company_id']."' WHERE `id` = '".$data['id']."' ";
//     $query = mysql_real_escape_string($query);
// 	return dbConnection()->exec($query);
// }

// function deleteSite($data)
// {
// 	$query = "DELETE FROM sites WHERE `id` = '".$data['id']."'";
//     $query = mysql_real_escape_string($query);
// 	return dbConnection()->exec($query);
// }

function insertBanche($data) 
{
	$query = "INSERT INTO banches(status, site_id) VALUES (:status, :site_id)";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':status' => $data['status'], 
        ':site_id' => $data['site_id']
    );
    return $sth->execute($data);
}

// function deleteBanche($data)
// {
// 	$query = "DELETE FROM banches WHERE `site_id` = '".$data['site_id']."' AND `created` BETWEEN '".$data['fromDate']."' AND '".$data['toDate']."' ";
//     $query = mysql_real_escape_string($query);
// 	return dbConnection()->exec($query);
// }

// function getCompany($data)
// {
//     $query = "SELECT * FROM companies WHERE `id` = '".$data['id']."'";
//     $query = mysql_real_escape_string($query);
//     return dbConnection()->query($query)->fetch();
// }

function getUser($data) 
{
    $query = "SELECT * FROM users WHERE `id` = :user_id OR `username` = :username ";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':user_id' => $data['user_id'],
        ':username' => $data['username']
    );

    $sth->execute($data);

    return $sth->fetch(PDO::FETCH_ASSOC);
}

function getSites($data)
{
    $query = "SELECT * FROM sites WHERE `company_id` = :company_id";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':company_id' => $data['company_id']
    );

    $sth->execute($data);

    return $sth->fetchAll(PDO::FETCH_ASSOC);
}

function getSite($data)
{
    $query = "SELECT * FROM sites WHERE `id` = :site_id";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':site_id' => $data['site_id']
    );

    $sth->execute($data);

    return $sth->fetch(PDO::FETCH_ASSOC);
}

function getBanches($data)
{
    $query = "SELECT * FROM banches WHERE `site_id` = :site_id AND `status` = 1";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':site_id' => $data['site_id']
    );

    $sth->execute($data);

    return $sth->fetchAll(PDO::FETCH_ASSOC);
}

function getBanche($data)
{
    $query = "SELECT * FROM banches WHERE `id` = :banche_id";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':banche_id' => $data['banche_id']
    );

    $sth->execute($data);

    return $sth->fetch(PDO::FETCH_ASSOC);
}

function getDevices($data)
{
    $query = "SELECT * FROM devices WHERE `banche_id` = :banche_id AND `type` = :type ";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':banche_id' => $data['banche_id'],
        ':type' => $data['type']
    );

    $sth->execute($data);

    return $sth->fetchAll(PDO::FETCH_ASSOC);
}

function getDeviceBySerialNumber($data)
{
    $query = "SELECT * FROM devices WHERE `banche_id` = :banche_id AND `serial_number` = :serial_number ";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':banche_id' => $data['banche_id'],
        ':serial_number' => $data['serial_number'],
    );

    $sth->execute($data);

    return $sth->fetch(PDO::FETCH_ASSOC);
}

function insertPressure($data)
{
    $query = "INSERT INTO pressures(pressure, device_id) VALUES (:pressure, :device_id)";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':pressure' => $data['pressure'], 
        ':device_id' => $data['device_id']
    );
    return $sth->execute($data);
}

function insertDistance($data)
{
    $query = "INSERT INTO distances(thickness, height, device_id) VALUES (:thickness, :height, :device_id)";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':thickness' => $data['thickness'], 
        ':height' => $data['height'], 
        ':device_id' => $data['device_id']
    );
    return $sth->execute($data);
}

function insertAlignment($data)
{
    $query = "INSERT INTO alignments(roll, pitch, device_id) VALUES (:roll, :pitch, :device_id)";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':roll' => $data['roll'], 
        ':pitch' => $data['pitch'], 
        ':device_id' => $data['device_id']
    );
    return $sth->execute($data);
}

function getPressures($data)
{
    $query = "SELECT * FROM (SELECT * FROM pressures WHERE `device_id` IN (:arr_device_id) AND (`created` BETWEEN :from AND :to ) ORDER BY `id` DESC LIMIT 100) dv ORDER BY `id` ASC ";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':arr_device_id' => $data['arr_device_id'],
        ':from' => $data['from'],
        ':to' => $data['to'],
    );

    $sth->execute($data);

    return $sth->fetchAll(PDO::FETCH_ASSOC);
}

function getRealTimePressure($data)
{
    if (!empty($data['last_id'])) {
        $query = "SELECT * FROM pressures WHERE `device_id` IN (:arr_device_id) AND `id` > :last_id ";
    } else {
        $query = "SELECT MAX(`id`) as id FROM pressures WHERE `device_id` IN (:arr_device_id)";
    }

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':arr_device_id' => $data['arr_device_id'],
        ':last_id' => $data['last_id']
    );

    $sth->execute($data);

    return $sth->fetchAll(PDO::FETCH_ASSOC);
}

function getDistances($data)
{
    $query = "SELECT * FROM (SELECT * FROM distances WHERE `device_id` IN (:arr_device_id) AND (`created` BETWEEN :from AND :to ) ORDER BY `id` DESC LIMIT 100) dv ORDER BY `id` ASC ";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':arr_device_id' => $data['arr_device_id'],
        ':from' => $data['from'],
        ':to' => $data['to'],
    );

    $sth->execute($data);

    return $sth->fetchAll(PDO::FETCH_ASSOC);
}

function getRealTimeDistance($data)
{
    if (!empty($data['last_id'])) {
        $query = "SELECT * FROM distances WHERE `device_id` IN (:arr_device_id) AND `id` > :last_id ";
    } else {
        $query = "SELECT MAX(`id`) as id FROM distances WHERE `device_id` IN (:arr_device_id)";
    }

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':arr_device_id' => $data['arr_device_id'],
        ':last_id' => $data['last_id']
    );

    $sth->execute($data);

    return $sth->fetchAll(PDO::FETCH_ASSOC);
}

function getAlignments($data)
{
    $query = "SELECT * FROM (SELECT * FROM alignments WHERE `device_id` IN (:arr_device_id) AND (`created` BETWEEN :from AND :to ) ORDER BY `id` DESC LIMIT 100) dv ORDER BY `id` ASC ";

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':arr_device_id' => $data['arr_device_id'],
        ':from' => $data['from'],
        ':to' => $data['to'],
    );

    $sth->execute($data);

    return $sth->fetchAll(PDO::FETCH_ASSOC);   
}

function getRealTimeAlignment($data)
{
    if (!empty($data['last_id'])) {
        $query = "SELECT * FROM alignments WHERE `device_id` IN (:arr_device_id) AND `id` > :last_id ";
    } else {
        $query = "SELECT MAX(`id`) as id FROM alignments WHERE `device_id` IN (:arr_device_id)";
    }

    $sth = dbConnection()->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

    $data = array(
        ':arr_device_id' => $data['arr_device_id'],
        ':last_id' => $data['last_id']
    );

    $sth->execute($data);

    return $sth->fetchAll(PDO::FETCH_ASSOC);
}

