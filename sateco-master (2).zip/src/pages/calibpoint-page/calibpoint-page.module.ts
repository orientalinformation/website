import { NgModule } from '@angular/core';
import { IonicModule } from 'ionic-angular';
import { CalibpointPage } from './calibpoint-page';

@NgModule({
  declarations: [
    CalibpointPage,
  ],
  exports: [
    CalibpointPage
  ]
})
export class CalibpointPageModule {}
