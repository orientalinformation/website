import { Component } from '@angular/core';
import { ModalController, IonicPage, NavController, NavParams } from 'ionic-angular';
import { AboutPage } from '../about/about';
import { ContactPage } from '../contact/contact';
import { CalibzeroPage } from '../calibzero-page/calibzero-page';

/**
 * Generated class for the SettingsPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-settings-page',
  templateUrl: 'settings-page.html',
})
export class SettingsPage {
  pressionPage: HTMLElement;
  inclinometerPage: any;
  distancePage: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController) {
   
    // document.querySelector("#nav2")['style'].display = 'none';
  }

  ionViewDidLoad() {
    this.pressionPage = <HTMLElement>document.querySelector("#pressionPage");
    this.inclinometerPage = <HTMLElement>document.querySelector("#inclinometerPage");
    this.distancePage = <HTMLElement>document.querySelector("#distancePage");
    this.showPressionPage();
  }

  showPressionPage(){
    this.pressionPage.style.display = "flex";
    this.inclinometerPage.style.display = "none";
    this.distancePage.style.display = "none";
    this.pressionPage.style.backgroundColor = "skyblue";
  }

  showIncinometerPage(){
    this.pressionPage.style.display = "none";
    this.inclinometerPage.style.display = "flex";
    this.distancePage.style.display = "none";
  }

  showDistancePage(){
    this.pressionPage.style.display = "none";
    this.inclinometerPage.style.display = "none";
    this.distancePage.style.display = "flex";
  }

  openCalibZero() {
    let modal = this.modalCtrl.create(CalibzeroPage);
    modal.present();
  }

  openCalibPoint(){
    let modal = this.modalCtrl.create(CalibzeroPage);
    modal.present();
  }

}