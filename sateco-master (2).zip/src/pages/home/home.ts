import { Component } from '@angular/core';
import {NavController,  Platform, AlertController} from 'ionic-angular';
import {File} from '@ionic-native/file';
import { GoogleMaps, GoogleMap, GoogleMapsEvent, LatLng, CameraPosition, MarkerOptions, Marker } from '@ionic-native/google-maps';
import { Storage } from '@ionic/storage';
import { DataService } from '../../providers/data-service';
import { AuthService } from '../../providers/auth-service';
import { SitePage } from '../../pages/site-page/site-page';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})

export class HomePage {
	map: any;
  	public site_id;

	constructor( private nav: NavController, private auth: AuthService, 
    public storage: Storage, public dataservice: DataService, private googleMaps: GoogleMaps)
	{
		var userInfo = this.auth.getUserInfo();

		this.dataservice.getSites(userInfo.token).subscribe(data => {
	      for (let _siteIndex in data){
	      	this.createMarker(this.map, this.nav, data[_siteIndex]);
	        // dtSites.push(new Site(data.sites[_siteItem].id, data.sites[_siteItem].name, data.sites[_siteItem].address, data.sites[_siteItem].lat, data.sites[_siteItem].lng));
	      }
	    });;
	}
	
  ngAfterViewInit() {
   this.loadMap();
  }

  loadMap() {
        // make sure to create following structure in your view.html file
        // and add a height (for example 100%) to it, else the map won't be visible
        // <ion-content>
        //  <div #map id="map" style="height:100%;"></div>
        // </ion-content>

        // create a new map by passing HTMLElementconst marker: any = map
        let element: HTMLElement = document.getElementById('map');

        let map: GoogleMap = this.googleMaps.create(element);

        // listen to MAP_READY event
        // You must wait for this event to fire before adding something to the map or modifying it in anyway
        map.one(GoogleMapsEvent.MAP_READY).then(() => {
            map.getMyLocation().then((userLocation) => {
	            // create LatLng object
	            let ionic: LatLng = new LatLng(userLocation.latLng.lat, userLocation.latLng.lng);
	            console.log(userLocation.latLng.lat + ' / ' + userLocation.latLng.lng);

	            // create CameraPosition
	            let position: CameraPosition = {
	                target: ionic,
	                zoom: 15,
	                tilt: 30
	            };

	            // move the map's camera to position
	            map.moveCamera(position);
          	});
        });
        this.map = map;
    };

  createMarker(map, nav, site) {
    let myLatlng: LatLng = new LatLng(site.lat, site.lng);
    map.addMarker({
      'position': myLatlng,
      'title': site.name,
      'address': site.address,
      'id': site.id,
      'markerClick': function(marker) {
        marker.showInfoWindow();
      },
      'infoClick': function(marker) {
        nav.push(SitePage, {
          site_id: site.id
        });
      }
    });
  }

  // public logout() {
  //   this.auth.logout().subscribe(succ => {
  //       this.storage.remove("id_token");
  //       this.nav.setRoot(LoginPage)
  //   });
  // }
}
