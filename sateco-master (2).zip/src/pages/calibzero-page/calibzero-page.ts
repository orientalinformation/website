import { Component } from '@angular/core';
import { ViewController, IonicPage, NavController, NavParams, LoadingController  } from 'ionic-angular';
import { SerialService } from '../../providers/serial-service';

/**
 * Generated class for the CalibzeroPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
 
declare function escape(s:string): string;
declare function unescape(s:string): string;

@IonicPage()
@Component({
  selector: 'page-calibzero-page',
  templateUrl: 'calibzero-page.html',
})

export class CalibzeroPage {
  private deviceId: string;
  constructor(public navCtrl: NavController, public navParams: NavParams,public viewCtrl: ViewController,
  	public loading: LoadingController, public serialService: SerialService) {
    this.deviceId = "DSP010001";
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CalibzeroPage');
  }

  closeModal() {
    this.viewCtrl.dismiss();
  }

  ionViewLoaded() {
	  let loader = this.loading.create({
	    content: 'Calibrating ...',
	  });

	  loader.present().then(() => {
      this.serialService.write("calibrate-zero\n");
      this.serialService.readyRead().subscribe(
          (data) => {//success callback
            let result = "";
            let view = new Uint8Array(data);
            let element: HTMLElement = document.getElementById('logger');
            for(var i in view){
              if(view[i] == 13){
                if(this.isComplete(result))
                  loader.dismiss();
              }else{
                result += unescape(escape(String.fromCharCode(view[i])));
              }
              element.innerHTML += unescape(escape(String.fromCharCode(view[i])));
            }
          },
          () => {//error callback

          },
          () => {}//complete callback
      );
	  });
	}

  isComplete(dtRespone: string): boolean{
    let dtResult = [];
    dtResult = dtRespone.split(" ");
    let dvId: string, key: string, value: string;
    dvId = dtResult[0];
    key = dtResult[1];
    value = dtResult[2];
    if ( this.deviceId == dvId && key == "calibrate-zero" ) {
      return true;
    }
    return false;
  }
}
