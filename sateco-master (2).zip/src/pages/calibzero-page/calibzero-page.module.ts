import { NgModule } from '@angular/core';
import { IonicModule } from 'ionic-angular';
import { CalibzeroPage } from './calibzero-page';

@NgModule({
  declarations: [
    CalibzeroPage,
  ],
  exports: [
    CalibzeroPage
  ]
})
export class CalibzeroPageModule {}
