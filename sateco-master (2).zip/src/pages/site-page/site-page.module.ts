import { NgModule } from '@angular/core';
import { IonicModule } from 'ionic-angular';
import { SitePage } from './site-page';

@NgModule({
  declarations: [
    SitePage,
  ],
  exports: [
    SitePage
  ]
})
export class SitePageModule {}
