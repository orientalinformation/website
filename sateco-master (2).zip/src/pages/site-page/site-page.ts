import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { SettingsPage } from '../../pages/settings-page/settings-page';

/**
 * Generated class for the SitePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-site-page',
  templateUrl: 'site-page.html',
})
export class SitePage {
  siteId: number;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.siteId = this.navParams.get("site_id");
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SitePage');
  }

  goSettings(){
  	console.log("go setting");

  	this.navCtrl.push(SettingsPage, {
      site_id: this.siteId
    });
  }

}
