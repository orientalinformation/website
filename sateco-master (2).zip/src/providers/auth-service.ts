import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import { Headers, Http, Request, RequestOptions, RequestMethod } from '@angular/http';
import 'rxjs/add/operator/map';
import { Storage } from '@ionic/storage';


export class User {
  username: string;
  password: string;
  token: string;

 
  constructor(username: string, password: string, token: string) {
    this.username = username;
    this.password = password;
    this.token = token;
  }
}

@Injectable()
export class AuthService {
  users: Array<User> = [];

  constructor(public http: Http, public storage: Storage) {
    storage.ready().then(() => {
       // Or to get a key/value pair
       storage.get('users').then( data => {
        if (data == null)
          this.users = [];
        else{
          this.users = JSON.parse(data);
        }
       }).catch((error: any) => {
         storage.set('users', '[]');
         this.users = [];
       });
     });

    
  }

  public host = "http://public.dfmvn.net/sateco";
  currentUser: User;

  public login(credentials) {
    var link = this.host + '/api/v1/user/login';
    let body = new FormData();
    body.append('username', credentials.username);
    body.append('password', credentials.password);    

    if (credentials.username === null || credentials.password === null) {
      return Observable.throw("Please insert credentials");
    } else {
      return Observable.create(observer => {
        // At this point make a request to your backend to make a real check!
        this.http.post(link, body).map(res => res.json())
        .subscribe(data => {
          var access = data.status;
          if (access){
            this.currentUser = new User(data.username, credentials.password, data.token);
            let isExist = false;
            for ( let user of this.users ) {
              if (user.username == credentials.username) {
                user.password = credentials.password;
                isExist = true;
              }
            }
            if (!isExist)
              this.users.push(this.currentUser);

            this.storage.set('users', JSON.stringify(this.users));  
          }

          observer.next(access);
          observer.complete();
        }, error => {
          //Check username password offline
          for ( let user of this.users ) {
            if (user.username == credentials.username && user.password == credentials.password) {
              observer.next(true);
              observer.complete();
            }
          }
        });
      });
    }
  }

  public register(credentials) {
    if (credentials.username === null || credentials.password === null) {
      return Observable.throw("Please insert credentials");
    } else if (credentials.password == credentials.password_confirm) {
      return Observable.create(observer => {
        var link = this.host + '/api/v1/register';
        var username = credentials.username;
        var password = credentials.password;
        var email = credentials.email;
        var company = "1";
        let body = new FormData();
        body.append('username', username);
        body.append('password', password);
        body.append('email', email);
        body.append('company_id', company);
        this.http.post(link, body).map(res => res.json())
        .subscribe(data => {
          observer.next(true);
          observer.complete();
        }, error => {
            console.log("Oooops!");
        });
      });
    } else {
      return Observable.throw("Please password confirm wrong!");
    }
      // At this point store the credentials to your backend!
  }
 
  public getUserInfo() : User {
    return this.currentUser;
  }

  public logout() {
    return Observable.create(observer => {
      var headers = new Headers();
      
      headers.append('Authorization', this.currentUser.token);

      var link = this.host + '/api/v1/user/logout';

      let options = new RequestOptions({
          method: RequestMethod.Get,
          url: link,
          headers: headers
      });
      this.http.request(new Request(options))
      .map(res => res.json())
          .subscribe(data => {
            let access = data.status;
            this.currentUser = null;
            observer.next(access);
            observer.complete();
          }, error => {
              console.log("Logout error");
          });
      });
  }

}
