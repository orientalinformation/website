import { Injectable } from '@angular/core';
import { Headers, Http, Request, RequestOptions, RequestMethod } from '@angular/http';
import {Observable} from 'rxjs/Observable';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map';

/*
  Generated class for the GetData provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/

export class Site {
  id: number;
  name: string;
  address: string;
  lat: number;
  lng: number;
 
  constructor(id: number, name: string, address: string, lat: number, lng: number) {
    this.id = id;
    this.name = name;
    this.address = address;
    this.lat = lat;
    this.lng = lng;
  }
}

export class Banches {
  banches: any;
  constructor(banches) {
    this.banches = banches;
  }
}

export class Reading {
  reading: any;
  constructor(reading) {
    this.reading = reading;
  }
}

@Injectable()
export class DataService {


  constructor(public http: Http, public storage: Storage) {
    storage.ready().then(() => {
       // Or to get a key/value pair
       storage.get('sites').then( data => {
        if (data == null)
          this.currentSites = [];
        else{
          this.currentSites = JSON.parse(data);
        }
       }).catch((error: any) => {
         storage.set('sites', '[]');
         this.currentSites = [];
       });
     });
  }

  public host = "http://public.dfmvn.net/sateco";
  currentSite: Site;
  currentSites: Array<Site> = [];
  currentBanches: Banches;
  currentReading: Reading;

  public getSiteInfo() : Site {
    return this.currentSite;
  }

  public getBanchesInfo() : Banches {
    return this.currentBanches;
  }

  public getReadingInfo() : Reading {
    return this.currentReading;
  }

  public getSite(token, site_id) {
    var headers = new Headers();
    headers.append('Authorization', token);

    var link = this.host + '/api/v1/site/' + site_id;
    let options = new RequestOptions({
        method: RequestMethod.Get,
        url: link,
        headers: headers
    });

    // this.currentSite = new Site(this.http.request(new Request(options)).map(res => res.json()));
  }

  public getSites(token) {
    var headers = new Headers();
    headers.append('Authorization', token);

    var link = this.host + '/api/v1/sites';
    let options = new RequestOptions({
        method: RequestMethod.Get,
        url: link,
        headers: headers
    });
    return Observable.create(observer => {
        // At this point make a request to your backend to make a real check!
       this.http.get(link, options).map(res => res.json())
        .subscribe(data => {
          //Loop data respone 
          for (let _siteItem in data.sites){
            //Create new site
            this.currentSite = new Site(data.sites[_siteItem].id, data.sites[_siteItem].name, 
              data.sites[_siteItem].address, data.sites[_siteItem].lat, data.sites[_siteItem].lng);

            let isExist = false;
            console.log("current site length" + this.currentSites.length);
            //Loop current site on database 
            if( this.currentSites.length < 1) {
              this.currentSites.push(this.currentSite);
            }
            else{
              for (var i in this.currentSites) {
                if( this.currentSites[i].name == this.currentSite.name && 
                  this.currentSites[i].lat == this.currentSite.lat && 
                  this.currentSites[i].lng == this.currentSite.lng){
                  this.currentSites[i] = this.currentSite;
                  isExist = true;
                  break;
                }else{
                  isExist = false;
                }
              }
              if( !isExist )
                this.currentSites.push(this.currentSite);
            }
          }
          this.storage.set('sites', JSON.stringify(this.currentSites));

          observer.next(this.currentSites);
          observer.complete();
        }, error => {
          //Check username password offline
          observer.next(this.currentSites);
          observer.complete();
        });
      });   
  }

  public saveSites(){
    var sites = new Storage({
      name: "__sites",
      driverOrder: ['indexeddb', 'sqlite', 'websql']
    });
    sites.set('alert', 'here');
  }

  public getBanches(token, site_id) {
    var headers = new Headers();
    headers.append('Authorization', token);

    var link = this.host + '/api/v1/banches/' + site_id;
    let options = new RequestOptions({
        method: RequestMethod.Get,
        url: link,
        headers: headers
    });
    this.currentBanches = new Banches(this.http.get(link, options).map(res => res.json()));
  }

  public getReading(token, banche_id) {
    var headers = new Headers();
    headers.append('Authorization', token);

    var link = this.host + '/api/v1/reading/' + banche_id;
    let options = new RequestOptions({
        method: RequestMethod.Get,
        url: link,
        headers: headers
    });
    this.currentReading = new Reading(this.http.get(link, options).map(res => res.json())); 
  }
}

