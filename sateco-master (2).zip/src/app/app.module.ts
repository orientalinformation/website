import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { App, MenuController, IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { Serial } from '@ionic-native/serial';
import {File} from '@ionic-native/file';
import { SerialService } from '../providers/serial-service';
import { AuthService } from '../providers/auth-service';
import { HttpModule } from '@angular/http';
import { IonicStorageModule } from '@ionic/storage';
import { DataService } from '../providers/data-service';
import { DbService } from '../providers/db-service';
import { GoogleMaps, GoogleMap, GoogleMapsEvent, LatLng, CameraPosition, MarkerOptions, Marker } from '@ionic-native/google-maps';

import { MyApp } from './app.component';

import { AboutPage } from '../pages/about/about';
import { ContactPage } from '../pages/contact/contact';
import { HomePage } from '../pages/home/home';
import { SettingsPage } from '../pages/settings-page/settings-page';
import { LoginPage } from '../pages/login-page/login-page';
import { SitePage } from '../pages/site-page/site-page';
import { CalibzeroPage } from '../pages/calibzero-page/calibzero-page';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

@NgModule({
  declarations: [
    MyApp,
    LoginPage,
    AboutPage,
    ContactPage,
    HomePage,
    SettingsPage,
    SitePage,
    CalibzeroPage
  ],
  imports: [
    BrowserModule,
    HttpModule,
    IonicStorageModule.forRoot({
      name: '__satecodb',
      driverOrder: ['indexeddb', 'sqlite', 'websql']
    }),
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    LoginPage,
    AboutPage,
    ContactPage,
    HomePage,
    SettingsPage,
    SitePage,
    CalibzeroPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    Serial,
    File,
    SerialService,
    AuthService,
    DataService,
    GoogleMaps,
    DbService,
    App,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
